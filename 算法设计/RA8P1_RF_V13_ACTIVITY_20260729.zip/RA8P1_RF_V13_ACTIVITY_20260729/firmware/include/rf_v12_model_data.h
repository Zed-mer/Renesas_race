#ifndef RF_V12_MODEL_DATA_H
#define RF_V12_MODEL_DATA_H

#include <stdint.h>

#define RF_V12_MODEL_MAX_OUTPUTS 5u
#define RF_V12_SHARED_ARENA_BYTES 189312u
#define RF_V12_COMMAND_WEIGHT_BYTES 24912u

#define RF_V12_V2_COMMAND_BYTES 2384u
#define RF_V12_V2_WEIGHT_BYTES 10320u
#define RF_V12_V2_SCRATCH_BYTES 189312u
#define RF_V12_V2_INPUT_BYTES 93840u
#define RF_V12_V2_OUTPUT_COUNT 5u
#define RF_V12_V3_COMMAND_BYTES 2176u
#define RF_V12_V3_WEIGHT_BYTES 10032u
#define RF_V12_V3_SCRATCH_BYTES 189312u
#define RF_V12_V3_INPUT_BYTES 93840u
#define RF_V12_V3_OUTPUT_COUNT 1u

typedef struct rf_v12_model_blob {
    const char *name;
    const uint8_t *command;
    const uint8_t *weights;
    uint32_t command_bytes;
    uint32_t weight_bytes;
    uint32_t weight_region;
    uint32_t scratch_region;
    uint32_t scratch_bytes;
    uint32_t input_region;
    uint32_t input_offset;
    uint32_t input_bytes;
    uint32_t output_count;
    uint32_t output_region[RF_V12_MODEL_MAX_OUTPUTS];
    uint32_t output_offset[RF_V12_MODEL_MAX_OUTPUTS];
    uint32_t output_bytes[RF_V12_MODEL_MAX_OUTPUTS];
} rf_v12_model_blob_t;

extern const rf_v12_model_blob_t g_rf_v12_v2_model;
extern const rf_v12_model_blob_t g_rf_v12_v3_model;

#endif
