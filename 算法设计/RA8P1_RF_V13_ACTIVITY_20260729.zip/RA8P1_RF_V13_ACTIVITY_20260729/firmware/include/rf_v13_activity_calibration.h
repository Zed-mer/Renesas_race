#ifndef RF_V13_ACTIVITY_CALIBRATION_H
#define RF_V13_ACTIVITY_CALIBRATION_H

#include "rf_v13_activity_fusion.h"

extern const rf_v13_activity_config_t g_rf_v13_deployment_config;

#endif
