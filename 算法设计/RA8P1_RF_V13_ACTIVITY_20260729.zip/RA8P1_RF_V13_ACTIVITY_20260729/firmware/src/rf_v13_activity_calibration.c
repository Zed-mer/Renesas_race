#include "rf_v13_activity_calibration.h"

/* Generated from validation INT8 score tails. See activity_calibration.json. */
const rf_v13_activity_config_t g_rf_v13_deployment_config = {
    RF_V13_ENERGY_LEAK_Q12,
    RF_V13_ENERGY_MIN_Q12,
    RF_V13_ENERGY_MAX_Q12,
    INT32_C(20480),
    INT32_C(2048),
    RF_V13_MISS_EVIDENCE_Q12,
    RF_V13_UNKNOWN_ROI_SCALE_Q12,
    RF_V13_MAX_PERIOD_BONUS_Q12,
    {
        {3u, {0u, 0u, 0u},
            {{UINT16_C(18022), INT16_C(2048)},
                {UINT16_C(24575), INT16_C(6144)},
                {UINT16_C(29490), INT16_C(11186)}}},
        {3u, {0u, 0u, 0u},
            {{UINT16_C(18022), INT16_C(2048)},
                {UINT16_C(24575), INT16_C(6144)},
                {UINT16_C(29490), INT16_C(12288)}}},
        {3u, {0u, 0u, 0u},
            {{UINT16_C(18022), INT16_C(2048)},
                {UINT16_C(24575), INT16_C(6144)},
                {UINT16_C(29490), INT16_C(10978)}}},
        {3u, {0u, 0u, 0u},
            {{UINT16_C(18022), INT16_C(2048)},
                {UINT16_C(24575), INT16_C(6144)},
                {UINT16_C(29490), INT16_C(9187)}}},
        {3u, {0u, 0u, 0u},
            {{UINT16_C(18022), INT16_C(2048)},
                {UINT16_C(24575), INT16_C(6144)},
                {UINT16_C(29490), INT16_C(12288)}}}
    }
};
