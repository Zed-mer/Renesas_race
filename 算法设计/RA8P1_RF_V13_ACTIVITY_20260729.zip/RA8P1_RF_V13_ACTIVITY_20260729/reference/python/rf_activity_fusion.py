from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum, IntEnum, IntFlag
from typing import Mapping, Sequence


CENTER_FREQUENCIES_HZ: tuple[int, ...] = (
    2_420_000_000,
    2_464_000_000,
    5_760_000_000,
    5_816_000_000,
)
TWO_FOUR_GHZ_CENTERS_HZ = frozenset(CENTER_FREQUENCIES_HZ[:2])


class DetectionClass(IntEnum):
    """Logical detector class IDs; these match the unchanged V2/V3 ABI."""

    DJI_CONTROL = 0
    DJI_VIDEO = 1
    AT9S = 2
    T12 = 3
    XIAOBAWANG = 4


class DeviceClass(IntEnum):
    DJI = 0
    AT9S = 1
    T12 = 2
    XIAOBAWANG = 3


DETECTION_TO_DEVICE: Mapping[DetectionClass, DeviceClass] = {
    DetectionClass.DJI_CONTROL: DeviceClass.DJI,
    DetectionClass.DJI_VIDEO: DeviceClass.DJI,
    DetectionClass.AT9S: DeviceClass.AT9S,
    DetectionClass.T12: DeviceClass.T12,
    DetectionClass.XIAOBAWANG: DeviceClass.XIAOBAWANG,
}


class RoiDecision(str, Enum):
    PASS = "PASS"
    UNKNOWN = "UNKNOWN"
    FAIL = "FAIL"


class ActivityState(str, Enum):
    """RF-observation state. NO_RF_OBSERVED must never be presented as OFF."""

    NO_RF_OBSERVED = "NO_RF_OBSERVED"
    UNCERTAIN = "UNCERTAIN"
    WORKING = "WORKING"


class FrequencyBand(str, Enum):
    BAND_2_4_GHZ = "2.4_GHZ"
    BAND_5_8_GHZ = "5.8_GHZ"


class TileValidity(IntEnum):
    INVALID = 0
    BACKGROUND_NOT_READY = 1
    VALID = 2


class TileQualityFlag(IntFlag):
    NONE = 0
    CRC_ERROR = 1 << 0
    PACKET_GAP = 1 << 1
    RETUNE_UNLOCKED = 1 << 2
    RING_OVERFLOW = 1 << 3
    ADC_SATURATION = 1 << 4
    CAPTURE_TIMEOUT = 1 << 5
    BACKGROUND_RESET = 1 << 6
    RESULT_TRUNCATED = 1 << 7


class UpdateReason(str, Enum):
    INITIALIZED = "INITIALIZED"
    POSITIVE_EVIDENCE = "POSITIVE_EVIDENCE"
    NEGATIVE_COMPLETE_ROUND = "NEGATIVE_COMPLETE_ROUND"
    INCOMPLETE_OR_INVALID_ROUND_HELD = "INCOMPLETE_OR_INVALID_ROUND_HELD"


class TransitionReason(str, Enum):
    INITIALIZED = "INITIALIZED"
    ENTERED_UNCERTAIN = "ENTERED_UNCERTAIN"
    ENTERED_WORKING = "ENTERED_WORKING"
    RETURNED_TO_NO_RF_OBSERVED = "RETURNED_TO_NO_RF_OBSERVED"
    EXITED_WORKING_AFTER_EVIDENCE_DECAY = "EXITED_WORKING_AFTER_EVIDENCE_DECAY"


@dataclass(frozen=True)
class ScoreLlrBin:
    minimum_score: float
    llr: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.minimum_score) or not 0.0 <= self.minimum_score <= 1.0:
            raise ValueError("minimum_score must be finite and within [0, 1]")
        if not math.isfinite(self.llr):
            raise ValueError("llr must be finite")

    def to_dict(self) -> dict[str, float]:
        return {"minimum_score": self.minimum_score, "llr": self.llr}


@dataclass(frozen=True)
class ScoreLlrTable:
    """Piecewise-constant calibrated score-to-LLR table.

    A score below the first bin is not credible RF evidence. The smoke table is
    intentionally replaceable by validation-calibrated per-class tables.
    """

    bins: tuple[ScoreLlrBin, ...] = (
        ScoreLlrBin(0.55, 0.5),
        ScoreLlrBin(0.75, 1.5),
        ScoreLlrBin(0.90, 3.0),
    )

    def __post_init__(self) -> None:
        if not self.bins:
            raise ValueError("score-to-LLR table must contain at least one bin")
        thresholds = [item.minimum_score for item in self.bins]
        if thresholds != sorted(thresholds) or len(set(thresholds)) != len(thresholds):
            raise ValueError("score-to-LLR bins must have unique ascending thresholds")

    def lookup(self, score: float) -> float | None:
        if not math.isfinite(score) or not 0.0 <= score <= 1.0:
            raise ValueError("score must be finite and within [0, 1]")
        result: float | None = None
        for item in self.bins:
            if score < item.minimum_score:
                break
            result = item.llr
        return result

    def to_dict(self) -> list[dict[str, float]]:
        return [item.to_dict() for item in self.bins]


def _default_llr_tables() -> dict[DetectionClass, ScoreLlrTable]:
    return {class_id: ScoreLlrTable() for class_id in DetectionClass}


@dataclass(frozen=True)
class FusionConfig:
    expected_centers_hz: tuple[int, ...] = CENTER_FREQUENCIES_HZ
    leak: float = 0.85
    evidence_min: float = -8.0
    evidence_max: float = 8.0
    working_enter_threshold: float = 4.0
    working_exit_threshold: float = 1.0
    no_rf_threshold: float = 1.0
    no_detection_llr: float = -0.25
    unknown_roi_scale: float = 0.5
    maximum_period_bonus: float = 0.3
    llr_tables: Mapping[DetectionClass, ScoreLlrTable] = field(
        default_factory=_default_llr_tables
    )

    def __post_init__(self) -> None:
        if len(self.expected_centers_hz) != 4 or len(set(self.expected_centers_hz)) != 4:
            raise ValueError("exactly four unique scan centers are required")
        if not 0.0 <= self.leak <= 1.0:
            raise ValueError("leak must be within [0, 1]")
        if self.evidence_min >= self.evidence_max:
            raise ValueError("evidence_min must be below evidence_max")
        if not self.evidence_min <= self.working_exit_threshold < self.working_enter_threshold <= self.evidence_max:
            raise ValueError("activity thresholds are inconsistent")
        if self.no_rf_threshold != self.working_exit_threshold:
            raise ValueError("NO_RF and WORKING-exit thresholds must match")
        if not 0.0 <= self.unknown_roi_scale <= 1.0:
            raise ValueError("unknown_roi_scale must be within [0, 1]")
        if not 0.0 <= self.maximum_period_bonus <= 0.3:
            raise ValueError("period bonus cap must be within [0, 0.3]")
        normalized: dict[DetectionClass, ScoreLlrTable] = {}
        for class_id in DetectionClass:
            try:
                normalized[class_id] = self.llr_tables[class_id]
            except KeyError as exc:
                raise ValueError(f"missing LLR table for {class_id.name}") from exc
        object.__setattr__(self, "llr_tables", normalized)


@dataclass(frozen=True)
class DetectionEvidence:
    class_id: DetectionClass
    confidence: float
    roi_decision: RoiDecision = RoiDecision.UNKNOWN
    period_bonus: float = 0.0
    event_id: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "class_id", DetectionClass(self.class_id))
        object.__setattr__(self, "roi_decision", RoiDecision(self.roi_decision))
        if not math.isfinite(self.confidence) or not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be finite and within [0, 1]")
        if not math.isfinite(self.period_bonus) or self.period_bonus < 0.0:
            raise ValueError("period_bonus must be finite and non-negative")

    def to_dict(self) -> dict[str, object]:
        return {
            "class_id": int(self.class_id),
            "class_name": self.class_id.name,
            "confidence": self.confidence,
            "roi_decision": self.roi_decision.value,
            "period_bonus": self.period_bonus,
            "event_id": self.event_id,
        }


@dataclass(frozen=True)
class TileObservation:
    center_frequency_hz: int
    capture_end_time_us: int
    events: tuple[DetectionEvidence, ...] = ()
    validity: TileValidity = TileValidity.VALID
    quality_flags: TileQualityFlag = TileQualityFlag.NONE

    def __post_init__(self) -> None:
        object.__setattr__(self, "events", tuple(self.events))
        object.__setattr__(self, "validity", TileValidity(self.validity))
        object.__setattr__(self, "quality_flags", TileQualityFlag(self.quality_flags))
        if self.center_frequency_hz <= 0:
            raise ValueError("center_frequency_hz must be positive")
        if self.capture_end_time_us < 0:
            raise ValueError("capture_end_time_us must be non-negative")

    @property
    def is_valid(self) -> bool:
        return self.validity is TileValidity.VALID and self.quality_flags == TileQualityFlag.NONE

    def to_dict(self) -> dict[str, object]:
        return {
            "center_frequency_hz": self.center_frequency_hz,
            "capture_end_time_us": self.capture_end_time_us,
            "validity": int(self.validity),
            "quality_flags": int(self.quality_flags),
            "events": [event.to_dict() for event in self.events],
        }


@dataclass(frozen=True)
class ScanRound:
    round_index: int
    end_time_us: int
    tiles: tuple[TileObservation, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "tiles", tuple(self.tiles))
        if self.round_index < 0 or self.end_time_us < 0:
            raise ValueError("round index and timestamp must be non-negative")

    def to_dict(self) -> dict[str, object]:
        return {
            "round_index": self.round_index,
            "end_time_us": self.end_time_us,
            "tiles": [tile.to_dict() for tile in self.tiles],
        }


@dataclass(frozen=True)
class DeviceRoundEvidence:
    device: DeviceClass
    llr: float
    credible_detection: bool
    source_class: DetectionClass | None = None
    confidence: float | None = None
    center_frequency_hz: int | None = None
    capture_end_time_us: int | None = None
    band: FrequencyBand | None = None
    roi_decision: RoiDecision | None = None
    accepted_before_dedup: int = 0

    def to_dict(self) -> dict[str, object]:
        return {
            "device": self.device.name,
            "llr": self.llr,
            "credible_detection": self.credible_detection,
            "source_class": None if self.source_class is None else self.source_class.name,
            "confidence": self.confidence,
            "center_frequency_hz": self.center_frequency_hz,
            "capture_end_time_us": self.capture_end_time_us,
            "band": None if self.band is None else self.band.value,
            "roi_decision": None if self.roi_decision is None else self.roi_decision.value,
            "accepted_before_dedup": self.accepted_before_dedup,
        }


@dataclass(frozen=True)
class AggregatedRound:
    round_index: int
    end_time_us: int
    complete_and_valid: bool
    quality_reason: str
    evidence: Mapping[DeviceClass, DeviceRoundEvidence]

    def to_dict(self) -> dict[str, object]:
        return {
            "round_index": self.round_index,
            "end_time_us": self.end_time_us,
            "complete_and_valid": self.complete_and_valid,
            "quality_reason": self.quality_reason,
            "evidence": {
                device.name: self.evidence[device].to_dict() for device in DeviceClass
            },
        }


@dataclass(frozen=True)
class DeviceActivity:
    device: DeviceClass
    state: ActivityState
    evidence: float
    last_trusted_detection_time_us: int | None
    evidence_source_class: DetectionClass | None
    last_center_frequency_hz: int | None
    last_band: FrequencyBand | None
    current_round_complete: bool
    last_update_reason: UpdateReason
    last_transition_reason: TransitionReason
    last_transition_time_us: int | None

    def to_dict(self) -> dict[str, object]:
        return {
            "device": self.device.name,
            "state": self.state.value,
            "evidence": self.evidence,
            "last_trusted_detection_time_us": self.last_trusted_detection_time_us,
            "evidence_source_class": (
                None if self.evidence_source_class is None else self.evidence_source_class.name
            ),
            "last_center_frequency_hz": self.last_center_frequency_hz,
            "last_band": None if self.last_band is None else self.last_band.value,
            "current_round_complete": self.current_round_complete,
            "last_update_reason": self.last_update_reason.value,
            "last_transition_reason": self.last_transition_reason.value,
            "last_transition_time_us": self.last_transition_time_us,
        }


@dataclass(frozen=True)
class FusionSnapshot:
    round_index: int
    end_time_us: int
    round_complete: bool
    round_quality_reason: str
    devices: Mapping[DeviceClass, DeviceActivity]

    def to_dict(self) -> dict[str, object]:
        return {
            "round_index": self.round_index,
            "end_time_us": self.end_time_us,
            "round_complete": self.round_complete,
            "round_quality_reason": self.round_quality_reason,
            "devices": {device.name: self.devices[device].to_dict() for device in DeviceClass},
        }


@dataclass(frozen=True)
class _AcceptedEvidence:
    class_id: DetectionClass
    confidence: float
    roi_decision: RoiDecision
    llr: float
    center_frequency_hz: int
    capture_end_time_us: int


def _frequency_band(center_frequency_hz: int) -> FrequencyBand:
    return (
        FrequencyBand.BAND_2_4_GHZ
        if center_frequency_hz < 4_000_000_000
        else FrequencyBand.BAND_5_8_GHZ
    )


def _round_quality(scan_round: ScanRound, config: FusionConfig) -> tuple[bool, str]:
    centers = [tile.center_frequency_hz for tile in scan_round.tiles]
    expected = set(config.expected_centers_hz)
    observed = set(centers)
    if len(scan_round.tiles) != len(config.expected_centers_hz):
        return False, "TILE_COUNT_MISMATCH"
    if observed != expected:
        return False, "CENTER_SET_MISMATCH"
    if len(observed) != len(centers):
        return False, "DUPLICATE_CENTER"
    invalid = [tile for tile in scan_round.tiles if not tile.is_valid]
    if invalid:
        return False, "INVALID_TILE_QUALITY"
    return True, "COMPLETE_VALID_ROUND"


def _event_is_in_allowed_band(event: DetectionEvidence, center_frequency_hz: int) -> bool:
    if event.class_id in (DetectionClass.DJI_CONTROL, DetectionClass.DJI_VIDEO):
        return True
    return center_frequency_hz in TWO_FOUR_GHZ_CENTERS_HZ


def _accepted_event(
    event: DetectionEvidence,
    tile: TileObservation,
    config: FusionConfig,
) -> _AcceptedEvidence | None:
    if event.roi_decision is RoiDecision.FAIL:
        return None
    if not _event_is_in_allowed_band(event, tile.center_frequency_hz):
        return None
    base_llr = config.llr_tables[event.class_id].lookup(event.confidence)
    if base_llr is None or base_llr <= 0.0:
        return None
    roi_scale = 1.0 if event.roi_decision is RoiDecision.PASS else config.unknown_roi_scale
    if roi_scale <= 0.0:
        return None
    period_bonus = min(event.period_bonus, config.maximum_period_bonus)
    llr = (base_llr + period_bonus) * roi_scale
    return _AcceptedEvidence(
        class_id=event.class_id,
        confidence=event.confidence,
        roi_decision=event.roi_decision,
        llr=llr,
        center_frequency_hz=tile.center_frequency_hz,
        capture_end_time_us=tile.capture_end_time_us,
    )


def aggregate_round(scan_round: ScanRound, config: FusionConfig | None = None) -> AggregatedRound:
    """Collapse one four-center scan into at most one observation per device.

    Same-class candidates are reduced with max evidence, and DJI control/video
    are then reduced with max evidence into one DJI observation. Counts never
    increase the LLR. This function does not alter or synthesize detection boxes.
    """

    config = config or FusionConfig()
    valid, quality_reason = _round_quality(scan_round, config)
    if not valid:
        held = {
            device: DeviceRoundEvidence(
                device=device,
                llr=0.0,
                credible_detection=False,
            )
            for device in DeviceClass
        }
        return AggregatedRound(
            round_index=scan_round.round_index,
            end_time_us=scan_round.end_time_us,
            complete_and_valid=False,
            quality_reason=quality_reason,
            evidence=held,
        )

    accepted_by_class: dict[DetectionClass, list[_AcceptedEvidence]] = {
        class_id: [] for class_id in DetectionClass
    }
    for tile in scan_round.tiles:
        for event in tile.events:
            accepted = _accepted_event(event, tile, config)
            if accepted is not None:
                accepted_by_class[accepted.class_id].append(accepted)

    best_by_class: dict[DetectionClass, _AcceptedEvidence] = {}
    for class_id, values in accepted_by_class.items():
        if values:
            best_by_class[class_id] = max(
                values,
                key=lambda item: (item.llr, item.confidence, item.capture_end_time_us),
            )

    evidence: dict[DeviceClass, DeviceRoundEvidence] = {}
    for device in DeviceClass:
        class_candidates = [
            item
            for class_id, item in best_by_class.items()
            if DETECTION_TO_DEVICE[class_id] is device
        ]
        if not class_candidates:
            evidence[device] = DeviceRoundEvidence(
                device=device,
                llr=config.no_detection_llr,
                credible_detection=False,
            )
            continue
        best = max(
            class_candidates,
            key=lambda item: (item.llr, item.confidence, item.capture_end_time_us),
        )
        accepted_count = sum(
            len(values)
            for class_id, values in accepted_by_class.items()
            if DETECTION_TO_DEVICE[class_id] is device
        )
        evidence[device] = DeviceRoundEvidence(
            device=device,
            llr=best.llr,
            credible_detection=True,
            source_class=best.class_id,
            confidence=best.confidence,
            center_frequency_hz=best.center_frequency_hz,
            capture_end_time_us=best.capture_end_time_us,
            band=_frequency_band(best.center_frequency_hz),
            roi_decision=best.roi_decision,
            accepted_before_dedup=accepted_count,
        )

    return AggregatedRound(
        round_index=scan_round.round_index,
        end_time_us=scan_round.end_time_us,
        complete_and_valid=True,
        quality_reason=quality_reason,
        evidence=evidence,
    )


class ActivityFusion:
    """CPU1 reference Leaky-SPRT state machine for four logical devices."""

    def __init__(self, config: FusionConfig | None = None) -> None:
        self.config = config or FusionConfig()
        self._last_round_index: int | None = None
        self._states: dict[DeviceClass, DeviceActivity] = {
            device: DeviceActivity(
                device=device,
                state=ActivityState.NO_RF_OBSERVED,
                evidence=0.0,
                last_trusted_detection_time_us=None,
                evidence_source_class=None,
                last_center_frequency_hz=None,
                last_band=None,
                current_round_complete=False,
                last_update_reason=UpdateReason.INITIALIZED,
                last_transition_reason=TransitionReason.INITIALIZED,
                last_transition_time_us=None,
            )
            for device in DeviceClass
        }

    @property
    def states(self) -> Mapping[DeviceClass, DeviceActivity]:
        return dict(self._states)

    def _next_state(self, previous: ActivityState, evidence: float) -> ActivityState:
        if previous is ActivityState.WORKING:
            return (
                ActivityState.NO_RF_OBSERVED
                if evidence < self.config.working_exit_threshold
                else ActivityState.WORKING
            )
        if evidence >= self.config.working_enter_threshold:
            return ActivityState.WORKING
        if evidence > self.config.no_rf_threshold:
            return ActivityState.UNCERTAIN
        return ActivityState.NO_RF_OBSERVED

    @staticmethod
    def _transition_reason(
        previous: ActivityState,
        current: ActivityState,
    ) -> TransitionReason | None:
        if previous is current:
            return None
        if current is ActivityState.WORKING:
            return TransitionReason.ENTERED_WORKING
        if current is ActivityState.UNCERTAIN:
            return TransitionReason.ENTERED_UNCERTAIN
        if previous is ActivityState.WORKING:
            return TransitionReason.EXITED_WORKING_AFTER_EVIDENCE_DECAY
        return TransitionReason.RETURNED_TO_NO_RF_OBSERVED

    def update(self, scan_round: ScanRound) -> FusionSnapshot:
        if self._last_round_index is not None and scan_round.round_index <= self._last_round_index:
            raise ValueError("round_index must be strictly increasing")
        aggregated = aggregate_round(scan_round, self.config)
        self._last_round_index = scan_round.round_index

        if not aggregated.complete_and_valid:
            self._states = {
                device: DeviceActivity(
                    device=device,
                    state=previous.state,
                    evidence=previous.evidence,
                    last_trusted_detection_time_us=previous.last_trusted_detection_time_us,
                    evidence_source_class=previous.evidence_source_class,
                    last_center_frequency_hz=previous.last_center_frequency_hz,
                    last_band=previous.last_band,
                    current_round_complete=False,
                    last_update_reason=UpdateReason.INCOMPLETE_OR_INVALID_ROUND_HELD,
                    last_transition_reason=previous.last_transition_reason,
                    last_transition_time_us=previous.last_transition_time_us,
                )
                for device, previous in self._states.items()
            }
            return self._snapshot(aggregated)

        next_states: dict[DeviceClass, DeviceActivity] = {}
        for device, previous in self._states.items():
            observation = aggregated.evidence[device]
            evidence = self.config.leak * previous.evidence + observation.llr
            evidence = min(self.config.evidence_max, max(self.config.evidence_min, evidence))
            state = self._next_state(previous.state, evidence)
            transition = self._transition_reason(previous.state, state)
            positive = observation.credible_detection
            next_states[device] = DeviceActivity(
                device=device,
                state=state,
                evidence=evidence,
                last_trusted_detection_time_us=(
                    observation.capture_end_time_us
                    if positive
                    else previous.last_trusted_detection_time_us
                ),
                evidence_source_class=(
                    observation.source_class if positive else previous.evidence_source_class
                ),
                last_center_frequency_hz=(
                    observation.center_frequency_hz
                    if positive
                    else previous.last_center_frequency_hz
                ),
                last_band=observation.band if positive else previous.last_band,
                current_round_complete=True,
                last_update_reason=(
                    UpdateReason.POSITIVE_EVIDENCE
                    if positive
                    else UpdateReason.NEGATIVE_COMPLETE_ROUND
                ),
                last_transition_reason=transition or previous.last_transition_reason,
                last_transition_time_us=(
                    scan_round.end_time_us
                    if transition is not None
                    else previous.last_transition_time_us
                ),
            )
        self._states = next_states
        return self._snapshot(aggregated)

    def _snapshot(self, aggregated: AggregatedRound) -> FusionSnapshot:
        return FusionSnapshot(
            round_index=aggregated.round_index,
            end_time_us=aggregated.end_time_us,
            round_complete=aggregated.complete_and_valid,
            round_quality_reason=aggregated.quality_reason,
            devices=dict(self._states),
        )


__all__ = [
    "ActivityFusion",
    "ActivityState",
    "AggregatedRound",
    "CENTER_FREQUENCIES_HZ",
    "DETECTION_TO_DEVICE",
    "DetectionClass",
    "DetectionEvidence",
    "DeviceActivity",
    "DeviceClass",
    "DeviceRoundEvidence",
    "FrequencyBand",
    "FusionConfig",
    "FusionSnapshot",
    "RoiDecision",
    "ScanRound",
    "ScoreLlrBin",
    "ScoreLlrTable",
    "TileObservation",
    "TileQualityFlag",
    "TileValidity",
    "TransitionReason",
    "TWO_FOUR_GHZ_CENTERS_HZ",
    "UpdateReason",
    "aggregate_round",
]
