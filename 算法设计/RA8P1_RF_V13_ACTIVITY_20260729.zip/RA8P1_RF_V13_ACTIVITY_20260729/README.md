# RA8P1 V13 最终无人机工作状态融合部署与回放验收

日期：2026-07-29  
状态：主机软件、INT8 分数标定、CPU1 C/Q20.12 实现和 C/Python Golden 已完成；真实连续四频点 IQ 与目标板固件验收仍待完成。  
结论：V13 是 V12 检测包的独立增量，不修改 V2/V3 模型 ABI，不增加 NPU arena，不覆盖 V12 回滚包。

固件接入请先阅读分享包内 `docs/固件对接手册.md`。其中给出了 CPU0 轮消息构造、CPU1 正式配置调用、512 B IPC 魔数区分、UI 映射、联调与回滚示例。

## 1. 正式链路

```text
IQ
 -> 1024 点 Hann STFT / hop 512
 -> 204F x 115T x 4 INT8 特征
 -> V2 非图传热图 + V3 图传 mask
 -> 固定框、频率/时间可见边界和 ROI 纹理复核
 -> 五类分数到 LLR 的验证集标定
 -> 四频点完整轮去重和聚合
 -> CPU1 Leaky SPRT
 -> DJI / AT9S / T12 / 小霸王三态输出
```

单个约 10 ms tile 只产生射频事件，绝不直接产生“无人机正在工作”结论。状态层只融合证据，不跨 retune 拼框、不跨频点生成框，也不补造周期框。

五类检测到四个状态对象的映射为：

| 检测类 | 状态对象 | 可接受中心频点 |
|---|---|---|
| 大疆遥控 | DJI | 2420/2464/5760/5816 MHz |
| 大疆图传 | DJI | 2420/2464/5760/5816 MHz |
| AT9S | AT9S | 2420/2464 MHz |
| T12 | T12 | 2420/2464 MHz |
| 小霸王 | 小霸王 | 2420/2464 MHz |

大疆遥控跨轮跳频时不要求频率坐标一致。大疆图传的稳定频带、周期和所有固定几何规则只允许提供总计不超过 `+0.3` 的软奖励。

## 2. CPU0 轮次关闭规则

CPU0 保留原 V12 tile 结果流，并在四个频点均结束后额外写一个 `rf_v13_cpu0_round_message_t`。消息固定 `512 B`，最多携带 `16` 条候选，恰好覆盖四个 tile 各最多四框的上限。候选只携带类别、置信度、ROI 判定、周期软奖励、中心槽和检测时间；框坐标仍只存在 V12 结果流中。

完整有效轮必须同时满足：

- `observed_slot_mask == valid_slot_mask == 0x0f`；
- 四个 V12 tile 均背景 ready，且无 CRC、缺包、队列溢出、retune 未锁定或采集超时；
- V12 ABI 和 tile 序列连续；
- 结果未因 top-K 或消息容量被截断。

任何条件失败时，CPU1 保持原证据值和原状态，既不加 `-0.25`，也不执行 `0.85` 泄漏。轮次索引跳跃本身不补算缺失轮，只记录可观测原因。

ROI 判定为 `PASS / UNKNOWN / FAIL`。`FAIL` 不进入状态证据但原检测框仍可显示；`UNKNOWN` 使用可配置的保守缩放，当前为 `0.5`。历史验证缓存没有 CPU0 ROI 判定日志，因此分数标定已经完成，ROI 分层标定仍需真实回放日志补齐。

## 3. 分数标定

标定脚本在 `drone-gpu` 中读取正式 V2/V3 INT8 验证 logits。每个 tile、每类只取最高局部热图分数，同类重复框不会增加统计权重。`unknown_rf` tile 排除；AT9S/T12/小霸王的 5.8 GHz 分数排除；工作态 hard negative 以 `2.0` 权重进入负分布。

本次使用 `22,340` 个验证 tile，得到 `74,728` 条类样本。采用 Laplace 平滑的累计尾部似然比，并作只向下修正的单调投影；为避免验证集中过少误报使弱分数被误判为强证据，三个分数档分别封顶 `+0.5/+1.5/+3.0`。

| 类别 | 正/负样本数 | 0.55–0.75 | 0.75–0.90 | >=0.90 |
|---|---:|---:|---:|---:|
| 大疆遥控 | 1,933 / 20,401 | +0.5 | +1.5 | +2.731 |
| 大疆图传 | 1,532 / 20,802 | +0.5 | +1.5 | +3.0 |
| AT9S | 801 / 9,219 | +0.5 | +1.5 | +2.680 |
| T12 | 1,199 / 8,821 | +0.5 | +1.5 | +2.243 |
| 小霸王 | 400 / 9,620 | +0.5 | +1.5 | +3.0 |

这些是检测证据的 LLR，不是未经校准的 sigmoid 概率。正式参数选择为：

```text
E_new = clip(0.85 * E_old + LLR_round, -8, 8)
WORKING enter: E >= 5.0
WORKING exit:  E < 0.5
UNCERTAIN:     0.5 < E < 5.0
NO_RF_OBSERVED: 其余非 WORKING 情况
complete valid miss: -0.25
invalid/incomplete round: hold exactly
```

进入阈值由初始 `4.0` 调至 `5.0`，退出阈值由 `1.0` 调至 `0.5`。原因是验证代理真空窗中，误进入从约 `8.38/h` 降到 `2.79/h`；强证据仍可在两轮进入，AT9S/T12 的较弱标定档需要三轮。进入后，合成回放可承受约 `6–8` 个完整空轮，符合不因单窗漏检闪烁的目标。

## 4. CPU1 定点实现

证据使用 `int32 Q20.12`：

```text
1.0       = 4096
leak 0.85 = 3482
min/max   = -32768 / 32768
miss      = -1024
period cap= 1229
deploy enter/exit = 20480 / 2048
```

可直接移植的主循环：

```c
if (!round_header_valid(msg))
    return BAD_MESSAGE;
if (duplicate_or_stale(msg))
    return IGNORE;
if (!complete_four_slots(msg) || msg->invalid_reason_flags != 0) {
    /* Important: no leak and no negative evidence. */
    hold_all_object_energy();
    record_invalid_reason();
    return HELD_INVALID_ROUND;
}

for (each evidence in msg) {
    reject_disallowed_band_only_for_state();
    llr = class_score_bin_lookup(evidence.class_id, evidence.confidence_q15);
    llr = (llr + min(period_bonus, 0.3)) * roi_scale;
    best_per_class[class_id] = max(best_per_class[class_id], llr);
}

best[DJI] = max(best_per_class[DJI_CONTROL], best_per_class[DJI_VIDEO]);
best[AT9S] = best_per_class[AT9S];
best[T12] = best_per_class[T12];
best[XIAOBAWANG] = best_per_class[XIAOBAWANG];

for (each device) {
    obs = has_positive(device) ? best[device] : -0.25;
    E = saturate_q12(round_q12(E * leak) + obs, -8, 8);
    apply_three_state_hysteresis();
    update_time_source_band_and_reason();
}
```

状态对象输出：三态、当前 `E`、最近可信检测时间、来源检测类、最近 2.4/5.8 GHz 频段、中心槽、当前轮完整/有效标志、最近更新原因、最近一次状态转换原因和时间。

`NO_RF_OBSERVED` 的唯一含义是“有效观察轮中未建立目标 RF 证据”。UI、日志、告警和外部协议均不得把它翻译为“设备关闭”。只有外部明确设备状态才能显示 `OFF`。

## 5. 资源开销

| 项目 | 开销 |
|---|---:|
| CPU1 四对象持久状态 | 304 B RAM |
| CPU0 完整轮消息 | 512 B/消息槽 |
| 五类标定和状态参数 | 212 B Flash/只读区 |
| 最大候选扫描 | 16 条/轮 |
| NPU arena 增量 | 0 B |
| heatmap/DTCM 增量 | 0 B |

每轮只执行至多 16 次分桶查表、若干 `int32/int64` 乘加和四个状态更新，复杂度为 `O(16 + 4)`。它不会改变当前约 `4.9–5.3 ms` 的双模型 NPU 调用，也不改变 `189,312 B` arena。实际 Cortex-M33 周期和 IPC 拥塞仍应在生产固件中测 p95。

## 6. 已执行回放和 Golden

软件验收包括：

- 单次孤立强误报不进入 WORKING；
- 大疆仅遥控或仅图传均可建立 WORKING；
- 大疆控制从 2.4 GHz 跳到 5.8 GHz 不丢状态；
- CRC/缺包类无效轮逐 bit 保持证据，不发生泄漏；
- 同类同轮多框取最大值，不按数量累加；
- AT9S/T12/小霸王的 5.8 GHz 候选不进入状态证据；
- C 与 Python 的 12 轮 Q20.12 trace 为 `12/12` 完全一致；
- 对 `0.75/0.85/0.92` 遗忘因子、`3.0/4.0/4.5/5.0` 进入阈值和 `0.5/1.0/1.5` 退出阈值完成消融。

验证代理将同一录音 stem、同一 tile 起点的四中心文件组成一轮，共 `4,954` 轮。正式参数下：

- 合成强证据确认：大疆控制/图传和小霸王 2 轮，AT9S/T12 3 轮；
- 真空窗代理：2,200 轮、0.3581 h，发生 1 次 DJI 误进入，即约 2.79/h；
- hard-negative 代理：29 轮，0 次误进入；样本时长过短，不能外推为 Wi-Fi/蓝牙正式指标；
- 历史稀疏检测对 AT9S/T12/小霸王不足以在代理序列稳定进入 WORKING，这属于检测召回和代理时序问题，不允许状态层通过复制框掩盖。

该代理不是实际连续 IQ。源文件是顺序采集的 100 ms 录音，且历史缓存没有实际 SDR gain 和 ROI verdict。真实四频点连续 IQ、宿舍 Wi-Fi/蓝牙分型、丢包注入和长时误报率仍是上板发布门禁。

## 7. 训练、部署和回滚

状态层不含可训练 NPU 参数，因此本次不重训 V2/V3；训练环境仍固定为 `drone-gpu`，标定和回放均从该环境执行。后续检测模型训练继续按 recording/task 分组，保留稀缺类重采样、工作态 hard negative、unknown ignore、PTQ/QAT 和真实 gain 分层；新模型只能在保持现有输出 ABI或同步升级固件解码器后替换。

部署顺序：

1. 保持 V12 模型 blob、arena offset、输出顺序和量化不变。
2. CPU0 从四个 V12 tile 关闭一个 V13 round message；框仍走原结果流。
3. CPU1 链接 `rf_v13_activity_fusion.c` 和生成的 `rf_v13_activity_calibration.c`。
4. UI 新增四个三态对象和证据可观测字段，但禁止出现由 RF 推断的 OFF。
5. 运行模型 tensor Golden、C/Python 状态 Golden、连续 IQ 回放和目标板长时测试。

回滚只需停止发送/消费 V13 round message，恢复 V12 UI 行为；V2/V3 模型、V12 ZIP、在线标注服务和标注数据库完全不变。

## 8. 产物和未关闭门禁

核心实现：

- `training/rf_activity_fusion.py`
- `deploy/ra8p1_v13/rf_v13_activity_fusion.h`
- `deploy/ra8p1_v13/rf_v13_activity_fusion.c`
- `scripts/calibrate_ra8p1_v13_activity.py`
- `scripts/replay_ra8p1_v13_activity.py`
- `scripts/verify_ra8p1_v13_c_golden.py`

机器报告位于 `output/ra8p1_v13_activity/`。未关闭门禁为：生产 CPU0/CPU1 固件工程、真实 IPC ring 接入、实际 SDR gain、IQ 到四通道 byte-exact Golden、真实连续四频点回放、Wi-Fi/蓝牙分型长时负样本，以及 Cortex-M33 周期/p95。完成这些门禁前，V13 只能标记为“固件集成候选”，不能标记为“已上板验收”。
