from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = PROJECT_ROOT / "output" / "ra8p1_v13_activity"
if (PROJECT_ROOT / "firmware" / "src" / "rf_v13_activity_fusion.c").is_file():
    SOURCE = PROJECT_ROOT / "firmware" / "src" / "rf_v13_activity_fusion.c"
    INCLUDE = PROJECT_ROOT / "firmware" / "include"
    DEFAULT_OUTPUT = PROJECT_ROOT / "golden" / "activity"
else:
    SOURCE = PROJECT_ROOT / "deploy" / "ra8p1_v13" / "rf_v13_activity_fusion.c"
    INCLUDE = SOURCE.parent
HARNESS = PROJECT_ROOT / "tests" / "c" / "rf_v13_activity_fusion_harness.c"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_hash(value: dict[str, object], field: str | None = None) -> str:
    payload = dict(value)
    if field:
        payload.pop(field, None)
    raw = json.dumps(
        payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _vcvars() -> Path:
    vswhere = Path(
        r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    )
    if not vswhere.is_file():
        raise FileNotFoundError("Visual Studio vswhere.exe is unavailable")
    result = subprocess.run(
        [
            str(vswhere),
            "-latest",
            "-products",
            "*",
            "-requires",
            "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
            "-property",
            "installationPath",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    path = (
        Path(result.stdout.strip())
        / "VC"
        / "Auxiliary"
        / "Build"
        / "vcvars64.bat"
    )
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def _q12_multiply(left: int, right: int) -> int:
    product = left * right
    if product >= 0:
        return (product + 2048) >> 12
    return -(((-product) + 2048) >> 12)


def _next_state(previous: int, energy: int) -> int:
    if previous == 2:
        return 0 if energy < 4096 else 2
    if energy >= 16384:
        return 2
    if energy > 4096:
        return 1
    return 0


def expected_trace() -> list[tuple[int, ...]]:
    energy = [0, 0, 0, 0]
    state = [0, 0, 0, 0]
    result = []
    for round_index in range(12):
        apply_result = 1 if round_index == 2 else 0
        if round_index != 2:
            observations = (
                [13517, 12288, -1024, -1024]
                if round_index < 2
                else [-1024] * 4
            )
            for object_id in range(4):
                energy[object_id] = max(
                    -32768,
                    min(
                        32768,
                        _q12_multiply(energy[object_id], 3482)
                        + observations[object_id],
                    ),
                )
                state[object_id] = _next_state(state[object_id], energy[object_id])
        row = [round_index, apply_result]
        for object_id in range(4):
            row.extend((energy[object_id], state[object_id]))
        result.append(tuple(row))
    return result


def run(output_dir: Path) -> dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    vcvars = _vcvars()
    with tempfile.TemporaryDirectory(prefix="rf_v13_c_golden_") as temporary:
        executable = Path(temporary) / "rf_v13_golden.exe"
        command = (
            "cl.exe /nologo /std:c11 /W4 /WX "
            f'"{HARNESS.resolve()}" '
            f'"{SOURCE.resolve()}" '
            f'/I "{INCLUDE.resolve()}" /Fe:"{executable}"'
        )
        compile_result = subprocess.run(
            f'call "{vcvars}" >nul && {command}',
            cwd=temporary,
            shell=True,
            executable=os.environ.get("COMSPEC", "cmd.exe"),
            check=False,
            capture_output=True,
            text=True,
        )
        if compile_result.returncode != 0:
            raise RuntimeError(compile_result.stdout + compile_result.stderr)
        completed = subprocess.run(
            [str(executable)], check=True, capture_output=True, text=True
        )
    trace_path = output_dir / "c_q20_12_trace.csv"
    trace_path.write_text(completed.stdout, encoding="ascii", newline="\n")
    observed = [
        tuple(int(value) for value in line.split(","))
        for line in completed.stdout.splitlines()
    ]
    expected = expected_trace()
    report: dict[str, object] = {
        "schema_version": "13.0.0",
        "pipeline": "ra8p1_v13_c_python_q20_12_golden",
        "passed": observed == expected,
        "round_count": len(expected),
        "exact_row_matches": sum(left == right for left, right in zip(observed, expected, strict=True)),
        "c_source_sha256": _sha256(SOURCE),
        "c_header_sha256": _sha256(INCLUDE / "rf_v13_activity_fusion.h"),
        "harness_sha256": _sha256(HARNESS),
        "trace_sha256": _sha256(trace_path),
        "coverage": [
            "duplicate same-class max reduction",
            "DJI hopping between 2.4 and 5.8 GHz",
            "two strong rounds enter WORKING",
            "invalid CRC round holds evidence without leak",
            "complete empty rounds decay with -0.25 LLR",
            "AT9S/T12/Xiaobawang 5.8 GHz class gate",
        ],
    }
    report["report_sha256"] = _canonical_hash(report, "report_sha256")
    report_path = output_dir / "c_python_q20_12_golden.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    if not report["passed"]:
        raise RuntimeError("C/Python Q20.12 traces differ")
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run V13 C/Python fixed-point Golden.")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def main() -> int:
    report = run(parse_args().output_dir.resolve())
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
