from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


V12_ARCHIVE_SHA256 = "1d3645feb0790381d5765a2238cc66cdf6de38013a85b511458d13c37132abb9"
EXPECTED_MODEL_HASHES = {
    "models/v2/model.int8.tflite": "6397630a1ccf9931ee71adceaeaa8da70811fb9d9338cab08d36ac62336ebcb2",
    "models/v3/model.int8.tflite": "ff4f31846cc9fa456baba538bca302e121a329bdfbca2fa0c28fa762715f813d",
    "models/v2/model.int8_vela.npz": "f1f94eed0c6fe5fb784fdfc881c6b660a10a497a3f84f0744ca438f9a96d9d8f",
    "models/v3/model.int8_vela.npz": "bff12700e9d77fafb011d09a957f198eaccb07f590ff7ccbe07d94f7209082dd",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_hash(value: dict[str, object], field: str | None = None) -> str:
    payload = dict(value)
    if field:
        payload.pop(field, None)
    raw = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def _inside(root: Path, relative: str) -> Path:
    path = (root / relative).resolve()
    if root.resolve() not in path.parents:
        raise ValueError(f"path escapes package root: {relative}")
    return path


def _verify_checksums(root: Path) -> list[str]:
    errors = []
    checksum_path = root / "SHA256SUMS.txt"
    expected: dict[str, str] = {}
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        expected[relative] = digest
    actual_paths = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS.txt"
    }
    if set(expected) != actual_paths:
        errors.append("SHA256SUMS file list differs from package files")
    for relative, digest in expected.items():
        path = _inside(root, relative)
        if not path.is_file() or _sha256(path) != digest:
            errors.append(f"checksum mismatch: {relative}")
    return errors


def _verify_manifest(root: Path) -> list[str]:
    errors = []
    report = _read_json(root / "PACKAGE_MANIFEST.json")
    if report.get("schema_version") != "13.0.0":
        errors.append("package manifest schema is not V13")
    if report.get("manifest_sha256") != _canonical_hash(report, "manifest_sha256"):
        errors.append("package manifest internal hash mismatch")
    artifacts = report.get("artifacts", {})
    if report.get("artifact_count") != len(artifacts):
        errors.append("package artifact count mismatch")
    for relative, metadata in artifacts.items():
        path = _inside(root, relative)
        if not path.is_file() or path.stat().st_size != metadata.get("bytes"):
            errors.append(f"manifest artifact bytes mismatch: {relative}")
        elif _sha256(path) != metadata.get("sha256"):
            errors.append(f"manifest artifact hash mismatch: {relative}")
    return errors


def _verify_detector(root: Path) -> list[str]:
    errors = []
    for relative, expected in EXPECTED_MODEL_HASHES.items():
        path = root / relative
        if not path.is_file() or _sha256(path) != expected:
            errors.append(f"frozen V12 detector artifact changed: {relative}")
    for model in ("v2", "v3"):
        path = root / "models" / model / "model.int8_vela.npz"
        if not path.is_file():
            continue
        with np.load(path, allow_pickle=True) as archive:
            if int(archive["scratch_size"]) != 189_312:
                errors.append(f"{model} NPU arena changed")
            if int(archive["input_offset"][0]) != 94_656:
                errors.append(f"{model} input arena offset changed")
    contract = _read_json(root / "config" / "deployment_contract.v13.json")
    base = contract.get("frozen_v12_detector", {})
    if base.get("rollback_archive_sha256") != V12_ARCHIVE_SHA256:
        errors.append("V12 rollback archive provenance changed")
    if contract.get("npu", {}).get("arena_increment_bytes") != 0:
        errors.append("V13 incorrectly changes NPU arena")
    if contract.get("npu", {}).get("output_abi_changed") is not False:
        errors.append("V13 incorrectly changes detector output ABI")
    return errors


def _verify_activity(root: Path) -> list[str]:
    errors = []
    readme = (root / "README.md").read_text(encoding="utf-8")
    if not readme.startswith("# RA8P1 V13"):
        errors.append("package README is not the V13 entry document")
    if "docs/固件对接手册.md" not in readme:
        errors.append("package README does not link the firmware integration guide")
    if "state_fusion_implementation_included=false" in readme:
        errors.append("package README still contains the obsolete V12 fusion claim")
    contract = _read_json(root / "config" / "deployment_contract.v13.json")
    if contract.get("contract_sha256") != _canonical_hash(contract, "contract_sha256"):
        errors.append("V13 deployment contract internal hash mismatch")
    if contract.get("activity_fusion", {}).get("implementation_included") is not True:
        errors.append("V13 contract does not include the state implementation")
    if contract.get("activity_fusion", {}).get("no_rf_observed_means_off") is not False:
        errors.append("NO_RF_OBSERVED is incorrectly mapped to OFF")
    header = (root / "firmware" / "include" / "rf_v13_activity_fusion.h").read_text(
        encoding="utf-8"
    )
    required_header = (
        "#define RF_V13_MISS_EVIDENCE_Q12 INT32_C(-1024)",
        "#define RF_V13_CPU0_MESSAGE_BYTES UINT16_C(512)",
        "RF_V13_ACTIVITY_NO_RF_OBSERVED = 0",
        "RF_V13_ACTIVITY_UNCERTAIN = 1",
        "RF_V13_ACTIVITY_WORKING = 2",
        "sizeof(rf_v13_cpu0_round_message_t) == 512u",
        "sizeof(rf_v13_activity_fusion_t) == 304u",
    )
    for text in required_header:
        if text not in header:
            errors.append(f"V13 firmware contract missing: {text}")
    source = (root / "firmware" / "src" / "rf_v13_activity_fusion.c").read_text(
        encoding="utf-8"
    )
    if "if (!complete_valid)" not in source or "RF_V13_REASON_INVALID_ROUND_HELD" not in source:
        errors.append("invalid-round hold implementation is missing")
    calibration = _read_json(root / "config" / "activity_calibration.json")
    if calibration.get("validation_tile_count") != 22_340:
        errors.append("calibration tile count changed")
    if calibration.get("fusion_defaults", {}).get("working_enter") != 5.0:
        errors.append("selected WORKING enter threshold changed")
    if calibration.get("fusion_defaults", {}).get("working_exit_strictly_below") != 0.5:
        errors.append("selected WORKING exit threshold changed")
    replay = _read_json(root / "reports" / "activity_replay_report.json")
    acceptance = replay.get("acceptance", {})
    if acceptance.get("software_gate_passed") is not True:
        errors.append("activity software replay gate failed")
    if acceptance.get("real_continuous_four_frequency_iq_gate_passed") is not False:
        errors.append("package falsely claims real continuous IQ acceptance")
    golden = _read_json(root / "golden" / "activity" / "c_python_q20_12_golden.json")
    if golden.get("passed") is not True or golden.get("exact_row_matches") != 12:
        errors.append("C/Python state Golden failed")
    trace = root / "golden" / "activity" / "c_q20_12_trace.csv"
    if golden.get("trace_sha256") != _sha256(trace):
        errors.append("C/Python state Golden trace hash mismatch")
    guide = (root / "docs" / "固件对接手册.md").read_text(encoding="utf-8")
    required_guide = (
        "当前应上板集成 **V13**",
        "g_rf_v13_deployment_config",
        "0x53323156",
        "0x46333156",
        "RF_V13_ROI_UNKNOWN",
        "RF_V13_APPLY_HELD_INVALID_ROUND",
        "NO_RF_OBSERVED",
        "rf_ipc_decode_slot_t",
        "RF_V13_INVALID_TILE_SEQUENCE",
        "map_v12_tile_failure_to_v13_invalid_flags",
        "CPU0 boot epoch",
        "独立的 `512 B` activity mailbox",
        "RA8P1_RF_V12_SPARSE_20260729.zip",
    )
    for text in required_guide:
        if text not in guide:
            errors.append(f"firmware integration guide missing contract text: {text}")
    return errors


def verify_package(root: Path) -> list[str]:
    required = (
        "README.md",
        "PACKAGE_MANIFEST.json",
        "SHA256SUMS.txt",
        "docs/固件对接手册.md",
        "config/deployment_contract.v13.json",
        "config/activity_calibration.json",
        "firmware/include/rf_v13_activity_fusion.h",
        "firmware/include/rf_v13_activity_calibration.h",
        "firmware/src/rf_v13_activity_fusion.c",
        "firmware/src/rf_v13_activity_calibration.c",
        "reports/activity_replay_report.json",
        "golden/activity/c_python_q20_12_golden.json",
        "golden/activity/c_q20_12_trace.csv",
        "reference/python/rf_activity_fusion.py",
        "training/rf_activity_fusion.py",
    )
    errors = [f"required file missing: {item}" for item in required if not (root / item).is_file()]
    if errors:
        return errors
    errors.extend(_verify_checksums(root))
    errors.extend(_verify_manifest(root))
    errors.extend(_verify_detector(root))
    errors.extend(_verify_activity(root))
    return errors


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Verify a RA8P1 V13 activity package.")
    parser.add_argument("package", type=Path, nargs="?", default=Path.cwd())
    return parser.parse_args()


def main() -> int:
    root = parse_args().package.resolve()
    errors = verify_package(root)
    print(
        json.dumps(
            {"status": "passed" if not errors else "failed", "package": str(root), "errors": errors},
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
