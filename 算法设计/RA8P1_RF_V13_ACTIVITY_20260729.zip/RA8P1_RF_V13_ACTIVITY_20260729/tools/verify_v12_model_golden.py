from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np


def _interpreter_class() -> Any:
    try:
        from ai_edge_litert.interpreter import Interpreter

        return Interpreter
    except ImportError:
        try:
            import tensorflow as tf

            return tf.lite.Interpreter
        except ImportError as exc:
            raise RuntimeError(
                "install ai-edge-litert or TensorFlow to execute the TFLite Golden"
            ) from exc


def verify(root: Path) -> list[dict[str, Any]]:
    root = root.resolve()
    manifest = json.loads(
        (root / "golden" / "golden_manifest.json").read_text(encoding="utf-8")
    )
    mappings = (("v2_nonvideo", "v2"), ("v3_video", "v3"))
    Interpreter = _interpreter_class()
    results: list[dict[str, Any]] = []
    for golden_name, package_name in mappings:
        entry = manifest["models"][golden_name]
        golden_root = root / "golden" / golden_name
        model_content = (
            root / "models" / package_name / "model.int8.tflite"
        ).read_bytes()
        interpreter = Interpreter(model_content=model_content)
        interpreter.allocate_tensors()
        input_details = interpreter.get_input_details()
        output_details = interpreter.get_output_details()
        if len(input_details) != 1:
            raise RuntimeError(f"{package_name} input count changed")
        expected_outputs = entry["outputs_in_interpreter_and_vela_order"]
        if len(output_details) != len(expected_outputs):
            raise RuntimeError(f"{package_name} output count changed")
        values = np.load(
            golden_root / entry["input"]["npy_path"], allow_pickle=False
        )
        interpreter.set_tensor(input_details[0]["index"], values)
        interpreter.invoke()
        for expected_entry, detail in zip(
            expected_outputs, output_details, strict=True
        ):
            expected = np.load(
                golden_root / expected_entry["npy_path"], allow_pickle=False
            )
            actual = interpreter.get_tensor(detail["index"])
            delta = np.abs(actual.astype(np.int16) - expected.astype(np.int16))
            record = {
                "model": package_name,
                "tensor": expected_entry["class_name"],
                "exact": bool(np.array_equal(actual, expected)),
                "max_abs_int8_delta": int(delta.max(initial=0)),
            }
            results.append(record)
    return results


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Execute the RA8P1 V12 TFLite tensor Golden."
    )
    parser.add_argument("package", type=Path, nargs="?", default=Path.cwd())
    args = parser.parse_args()
    results = verify(args.package)
    passed = all(item["exact"] for item in results)
    print(
        json.dumps(
            {
                "status": "passed" if passed else "failed",
                "package": str(args.package.resolve()),
                "results": results,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
