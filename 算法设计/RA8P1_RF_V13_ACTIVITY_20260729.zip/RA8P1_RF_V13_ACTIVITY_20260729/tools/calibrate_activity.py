from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CACHE = PROJECT_ROOT / "output" / "onboard_cache_exact_balanced_20260728"
DEFAULT_V2_RUN = (
    PROJECT_ROOT / "output" / "rf_onboard_v2" / "rf_onboard_v2_9db188f45882de2c"
)
DEFAULT_V3_RUN = (
    PROJECT_ROOT
    / "output"
    / "rf_onboard_video_mask_v3"
    / "rf_onboard_video_mask_v3_3eb5a9a5d6219482"
)
DEFAULT_OUTPUT = PROJECT_ROOT / "output" / "ra8p1_v13_activity"

CLASS_NAMES = (
    "dji_control_fhss",
    "dji_video_link",
    "radiolink_at9s_fhss",
    "yunzhuo_t12_fhss",
    "xiaobawang_fhss",
)
DEFAULT_THRESHOLDS = (0.55, 0.75, 0.90)
V2_SCALES = np.asarray(
    (0.03540739044547081, 0.03002132475376129, 0.05212867632508278,
     0.03770545497536659, 0.044470448046922684),
    dtype=np.float64,
)
V2_ZERO_POINTS = np.asarray((89, 104, 106, 102, 109), dtype=np.int16)
V3_SCALE = 0.09589578956365585
V3_ZERO_POINT = 62
Q15_ONE = 32767
Q12_ONE = 4096


@dataclass(frozen=True)
class CalibrationSample:
    class_id: int
    score: float
    positive: bool
    negative_kind: str
    weight: float = 1.0


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_hash(value: dict[str, object], field: str | None = None) -> str:
    payload = dict(value)
    if field is not None:
        payload.pop(field, None)
    raw = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def _write_json(path: Path, value: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _sigmoid(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    return np.where(
        values >= 0,
        1.0 / (1.0 + np.exp(-values)),
        np.exp(values) / (1.0 + np.exp(values)),
    )


def _load_validation_rows(cache: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    with (cache / "tiles.jsonl").open("r", encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if row["split"] == "validation":
                rows.append(row)
    return rows


def _load_peak_scores(
    v2_logits: Path,
    v3_logits: Path,
    tile_count: int,
    batch_size: int = 128,
) -> np.ndarray:
    expected_v2 = tile_count * 102 * 58 * 5
    expected_v3 = tile_count * 102 * 58
    if v2_logits.stat().st_size != expected_v2:
        raise ValueError(
            f"V2 logits bytes mismatch: {v2_logits.stat().st_size} != {expected_v2}"
        )
    if v3_logits.stat().st_size != expected_v3:
        raise ValueError(
            f"V3 logits bytes mismatch: {v3_logits.stat().st_size} != {expected_v3}"
        )
    v2 = np.memmap(v2_logits, dtype=np.int8, mode="r", shape=(tile_count, 102, 58, 5))
    v3 = np.memmap(v3_logits, dtype=np.int8, mode="r", shape=(tile_count, 102, 58))
    result = np.empty((tile_count, 5), dtype=np.float32)
    for start in range(0, tile_count, batch_size):
        stop = min(tile_count, start + batch_size)
        peaks = np.asarray(v2[start:stop]).max(axis=(1, 2)).astype(np.int16)
        logits = (peaks - V2_ZERO_POINTS[None, :]) * V2_SCALES[None, :]
        result[start:stop] = _sigmoid(logits).astype(np.float32)
        video_peaks = np.asarray(v3[start:stop]).max(axis=(1, 2)).astype(np.int16)
        video_logits = (video_peaks - V3_ZERO_POINT) * V3_SCALE
        result[start:stop, 1] = _sigmoid(video_logits).astype(np.float32)
    return result


def _center_slot(recording_id: str) -> int:
    match = re.search(r"_f([0-3])$", recording_id)
    if match is None:
        raise ValueError(f"recording id has no center slot suffix: {recording_id}")
    return int(match.group(1))


def build_samples(
    rows: Sequence[dict[str, object]],
    peak_scores: np.ndarray,
    hard_negative_weight: float,
) -> list[CalibrationSample]:
    if peak_scores.shape != (len(rows), 5):
        raise ValueError("peak score shape does not match validation rows")
    samples: list[CalibrationSample] = []
    for row, scores in zip(rows, peak_scores, strict=True):
        if bool(row.get("has_ignore", False)):
            continue
        positives = {int(value) for value in row.get("class_indices", [])}
        slot = _center_slot(str(row["recording_id"]))
        for class_id, score in enumerate(scores):
            if class_id >= 2 and slot >= 2:
                continue
            positive = class_id in positives
            if positive:
                kind = "positive"
                weight = 1.0
            elif bool(row.get("hard_negative", False)):
                kind = "hard_negative"
                weight = hard_negative_weight
            elif not positives:
                kind = "true_empty"
                weight = 1.0
            else:
                kind = "other_class_negative"
                weight = 1.0
            samples.append(
                CalibrationSample(
                    class_id=class_id,
                    score=float(score),
                    positive=positive,
                    negative_kind=kind,
                    weight=weight,
                )
            )
    return samples


def _quantiles(values: np.ndarray) -> dict[str, float | None]:
    if not values.size:
        return {name: None for name in ("p05", "p25", "p50", "p75", "p95", "p99")}
    points = np.quantile(values, (0.05, 0.25, 0.50, 0.75, 0.95, 0.99))
    return {
        name: float(value)
        for name, value in zip(("p05", "p25", "p50", "p75", "p95", "p99"), points, strict=True)
    }


def fit_llr_table(
    samples: Sequence[CalibrationSample],
    thresholds: Sequence[float] = DEFAULT_THRESHOLDS,
    alpha: float = 1.0,
    llr_caps: Sequence[float] = (0.5, 1.5, 3.0),
) -> dict[str, object]:
    if not thresholds or tuple(thresholds) != tuple(sorted(set(thresholds))):
        raise ValueError("thresholds must be unique and ascending")
    if alpha <= 0.0 or len(llr_caps) != len(thresholds):
        raise ValueError("alpha must be positive and every threshold needs an LLR cap")
    if tuple(llr_caps) != tuple(sorted(llr_caps)) or min(llr_caps) <= 0.0:
        raise ValueError("LLR caps must be positive and nondecreasing")
    positives = [item for item in samples if item.positive]
    negatives = [item for item in samples if not item.positive]
    if not positives or not negatives:
        raise ValueError("both positive and negative calibration samples are required")
    positive_total = sum(item.weight for item in positives)
    negative_total = sum(item.weight for item in negatives)
    raw: list[float] = []
    bins: list[dict[str, object]] = []
    for threshold in thresholds:
        positive_tail = sum(item.weight for item in positives if item.score >= threshold)
        negative_tail = sum(item.weight for item in negatives if item.score >= threshold)
        positive_rate = (positive_tail + alpha) / (positive_total + 2.0 * alpha)
        negative_rate = (negative_tail + alpha) / (negative_total + 2.0 * alpha)
        llr = math.log(positive_rate / negative_rate)
        raw.append(llr)
        bins.append(
            {
                "minimum_score": float(threshold),
                "minimum_confidence_q15": int(round(threshold * Q15_ONE)),
                "positive_tail_weight": positive_tail,
                "negative_tail_weight": negative_tail,
                "positive_tail_rate": positive_rate,
                "negative_tail_rate": negative_rate,
                "raw_llr": llr,
            }
        )
    # Tail estimates are nested and noisy. Project conservatively by only
    # lowering bins until they are monotonic, then apply the deployment tier
    # caps. This never turns a weak 0.55 score into a +3 observation merely
    # because the validation split contains few false positives.
    raw_values = np.asarray(raw, dtype=np.float64)
    monotonic = np.minimum.accumulate(raw_values[::-1])[::-1]
    monotonic = np.maximum(monotonic, -8.0)
    monotonic = np.minimum(monotonic, np.asarray(llr_caps, dtype=np.float64))
    for record, value in zip(bins, monotonic, strict=True):
        record["llr"] = float(value)
        record["llr_q12"] = int(round(float(value) * Q12_ONE))
    by_kind: dict[str, list[float]] = {}
    for item in samples:
        by_kind.setdefault(item.negative_kind, []).append(item.score)
    return {
        "positive_sample_count": len(positives),
        "negative_sample_count": len(negatives),
        "positive_weight": positive_total,
        "negative_weight": negative_total,
        "score_quantiles": {
            kind: _quantiles(np.asarray(values, dtype=np.float64))
            for kind, values in sorted(by_kind.items())
        },
        "bins": bins,
        "method": "smoothed cumulative-tail log likelihood ratio with conservative monotonic projection and tier caps",
        "laplace_alpha": alpha,
        "llr_caps": list(llr_caps),
    }


def calibrate(samples: Sequence[CalibrationSample]) -> dict[str, object]:
    classes: dict[str, object] = {}
    for class_id, name in enumerate(CLASS_NAMES):
        class_samples = [item for item in samples if item.class_id == class_id]
        table = fit_llr_table(class_samples)
        table["class_id"] = class_id
        classes[name] = table
    return classes


def _c_initializer(classes: dict[str, object]) -> str:
    class_blocks: list[str] = []
    for name in CLASS_NAMES:
        table = classes[name]
        bins = table["bins"]
        entries = ",\n                ".join(
            "{UINT16_C(%d), INT16_C(%d)}"
            % (item["minimum_confidence_q15"], item["llr_q12"])
            for item in bins
        )
        class_blocks.append(
            "        {%du, {0u, 0u, 0u},\n"
            "            {%s}}" % (len(bins), entries)
        )
    return ",\n".join(class_blocks)


def write_c_config(output_dir: Path, report: dict[str, object]) -> tuple[Path, Path]:
    include_path = output_dir / "rf_v13_activity_calibration.h"
    source_path = output_dir / "rf_v13_activity_calibration.c"
    include_path.write_text(
        "#ifndef RF_V13_ACTIVITY_CALIBRATION_H\n"
        "#define RF_V13_ACTIVITY_CALIBRATION_H\n\n"
        "#include \"rf_v13_activity_fusion.h\"\n\n"
        "extern const rf_v13_activity_config_t g_rf_v13_deployment_config;\n\n"
        "#endif\n",
        encoding="ascii",
        newline="\n",
    )
    defaults = report["fusion_defaults"]
    source = f'''#include "rf_v13_activity_calibration.h"

/* Generated from validation INT8 score tails. See activity_calibration.json. */
const rf_v13_activity_config_t g_rf_v13_deployment_config = {{
    RF_V13_ENERGY_LEAK_Q12,
    RF_V13_ENERGY_MIN_Q12,
    RF_V13_ENERGY_MAX_Q12,
    INT32_C({round(float(defaults["working_enter"]) * Q12_ONE)}),
    INT32_C({round(float(defaults["working_exit_strictly_below"]) * Q12_ONE)}),
    RF_V13_MISS_EVIDENCE_Q12,
    RF_V13_UNKNOWN_ROI_SCALE_Q12,
    RF_V13_MAX_PERIOD_BONUS_Q12,
    {{
{_c_initializer(report["classes"])}
    }}
}};
'''
    source_path.write_text(source, encoding="ascii", newline="\n")
    return include_path, source_path


def _artifact(path: Path) -> dict[str, object]:
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": _sha256(path)}


def run(args: argparse.Namespace) -> dict[str, object]:
    cache = args.cache.resolve()
    v2_logits = args.v2_logits.resolve()
    v3_logits = args.v3_logits.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = _load_validation_rows(cache)
    scores = _load_peak_scores(v2_logits, v3_logits, len(rows), args.batch_size)
    score_path = output_dir / "validation_peak_scores.f32.npy"
    np.save(score_path, scores, allow_pickle=False)
    samples = build_samples(rows, scores, args.hard_negative_weight)
    classes = calibrate(samples)
    report: dict[str, object] = {
        "schema_version": "13.0.0",
        "pipeline": "ra8p1_v13_int8_peak_score_llr_calibration",
        "status": "validation_score_calibrated_roi_stratification_pending_board_logs",
        "claim": "grouped-validation calibration for an auxiliary RF activity state; not device power-state inference",
        "class_order": list(CLASS_NAMES),
        "classes": classes,
        "fusion_defaults": {
            "leak": 0.85,
            "working_enter": 5.0,
            "working_exit_strictly_below": 0.5,
            "complete_round_miss_llr": -0.25,
            "invalid_round_llr": 0.0,
            "invalid_round_applies_leak": False,
            "maximum_period_bonus": 0.3,
            "unknown_roi_scale": 0.5,
        },
        "sample_policy": {
            "positive": "validation tile contains the class",
            "true_empty": "validation tile contains no approved target class",
            "hard_negative": "cache row hard_negative=true; weighted in the negative distribution",
            "other_class_negative": "tile contains another target class but not this class",
            "unknown_rf": "has_ignore=true rows excluded",
            "frequency_gate": "AT9S/T12/Xiaobawang samples restricted to center slots 0 and 1",
            "round_dedup": "calibration uses one maximum local-heatmap score per class and tile; runtime uses max per class per round",
            "hard_negative_weight": args.hard_negative_weight,
        },
        "limitations": [
            "The validation split was used for threshold/model selection and is not a locked independent test.",
            "Rows are 50-percent-overlap 10 ms tiles, not a timestamped continuous four-frequency capture.",
            "The table calibrates deployed INT8 heatmap peak scores. Existing cache rows do not carry CPU0 ROI PASS/FAIL logs, so ROI scaling remains the conservative smoke setting until continuous board replay logs are collected.",
            "NO_RF_OBSERVED means no credible target RF in valid observed rounds and never means that a device is powered off.",
        ],
        "artifacts": {
            "cache_manifest": _artifact(cache / "cache_manifest.json"),
            "tiles": _artifact(cache / "tiles.jsonl"),
            "v2_logits": _artifact(v2_logits),
            "v2_logits_manifest": _artifact(Path(str(v2_logits) + ".manifest.json")),
            "v3_logits": _artifact(v3_logits),
            "v3_logits_manifest": _artifact(Path(str(v3_logits) + ".manifest.json")),
            "validation_peak_scores": _artifact(score_path),
        },
        "validation_tile_count": len(rows),
        "calibration_sample_count": len(samples),
    }
    report["report_sha256"] = _canonical_hash(report, "report_sha256")
    report_path = output_dir / "activity_calibration.json"
    _write_json(report_path, report)
    header, source = write_c_config(output_dir, report)
    manifest = {
        "schema_version": "13.0.0",
        "report": _artifact(report_path),
        "generated_header": _artifact(header),
        "generated_source": _artifact(source),
    }
    manifest["manifest_sha256"] = _canonical_hash(manifest, "manifest_sha256")
    _write_json(output_dir / "activity_calibration_manifest.json", manifest)
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Calibrate V13 per-class INT8 detector scores into LLR tables."
    )
    parser.add_argument("--cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument(
        "--v2-logits",
        type=Path,
        default=DEFAULT_V2_RUN / "validation_logits.split-heads.int8",
    )
    parser.add_argument(
        "--v3-logits",
        type=Path,
        default=DEFAULT_V3_RUN / "validation_logits.int8.bin",
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--hard-negative-weight", type=float, default=2.0)
    parser.add_argument("--batch-size", type=int, default=128)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.hard_negative_weight <= 0.0 or args.batch_size <= 0:
        raise ValueError("weights and batch size must be positive")
    report = run(args)
    print(
        json.dumps(
            {
                "status": report["status"],
                "output": str(args.output_dir.resolve()),
                "validation_tile_count": report["validation_tile_count"],
                "calibration_sample_count": report["calibration_sample_count"],
                "report_sha256": report["report_sha256"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
