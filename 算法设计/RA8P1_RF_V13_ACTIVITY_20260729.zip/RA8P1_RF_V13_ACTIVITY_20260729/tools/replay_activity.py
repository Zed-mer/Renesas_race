from __future__ import annotations

import argparse
import hashlib
import json
import re
import statistics
import sys
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from training.rf_activity_fusion import (
    ActivityFusion,
    ActivityState,
    CENTER_FREQUENCIES_HZ,
    DETECTION_TO_DEVICE,
    DetectionClass,
    DetectionEvidence,
    DeviceClass,
    FusionConfig,
    RoiDecision,
    ScanRound,
    ScoreLlrBin,
    ScoreLlrTable,
    TileObservation,
    TileQualityFlag,
    TileValidity,
)


DEFAULT_ACTIVITY_DIR = PROJECT_ROOT / "output" / "ra8p1_v13_activity"
DEFAULT_CACHE = PROJECT_ROOT / "output" / "onboard_cache_exact_balanced_20260728"
ROUND_DURATION_US = 586_000


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_hash(value: dict[str, object], field: str | None = None) -> str:
    payload = dict(value)
    if field is not None:
        payload.pop(field, None)
    raw = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _write_json(path: Path, value: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def config_from_report(report: Mapping[str, object]) -> FusionConfig:
    classes = report["classes"]
    tables: dict[DetectionClass, ScoreLlrTable] = {}
    class_names = (
        "dji_control_fhss",
        "dji_video_link",
        "radiolink_at9s_fhss",
        "yunzhuo_t12_fhss",
        "xiaobawang_fhss",
    )
    for class_id, name in enumerate(class_names):
        bins = classes[name]["bins"]
        tables[DetectionClass(class_id)] = ScoreLlrTable(
            tuple(
                ScoreLlrBin(float(item["minimum_score"]), float(item["llr"]))
                for item in bins
            )
        )
    defaults = report["fusion_defaults"]
    return FusionConfig(
        leak=float(defaults["leak"]),
        working_enter_threshold=float(defaults["working_enter"]),
        working_exit_threshold=float(defaults["working_exit_strictly_below"]),
        no_rf_threshold=float(defaults["working_exit_strictly_below"]),
        no_detection_llr=float(defaults["complete_round_miss_llr"]),
        unknown_roi_scale=float(defaults["unknown_roi_scale"]),
        maximum_period_bonus=float(defaults["maximum_period_bonus"]),
        llr_tables=tables,
    )


def _load_validation_rows(cache: Path) -> list[dict[str, object]]:
    rows = []
    with (cache / "tiles.jsonl").open("r", encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if row["split"] == "validation":
                rows.append(row)
    return rows


def _recording_base_and_slot(recording_id: str) -> tuple[str, int]:
    match = re.search(r"_f([0-3])$", recording_id)
    if match is None:
        raise ValueError(f"recording id has no center suffix: {recording_id}")
    return recording_id[: match.start()], int(match.group(1))


def _lowest_threshold(config: FusionConfig, class_id: DetectionClass) -> float:
    return config.llr_tables[class_id].bins[0].minimum_score


def build_validation_proxy_sequences(
    cache: Path,
    peak_scores_path: Path,
    config: FusionConfig,
) -> dict[str, list[tuple[ScanRound, frozenset[DeviceClass], str]]]:
    rows = _load_validation_rows(cache)
    scores = np.load(peak_scores_path, mmap_mode="r", allow_pickle=False)
    if scores.shape != (len(rows), 5):
        raise ValueError("validation peak scores do not match cache rows")
    grouped: dict[tuple[str, int], dict[int, tuple[dict[str, object], np.ndarray]]] = defaultdict(dict)
    for row, row_scores in zip(rows, scores, strict=True):
        base, slot = _recording_base_and_slot(str(row["recording_id"]))
        grouped[(base, int(row["tile_start_sample"]))][slot] = (row, row_scores)
    sequences: dict[str, list[tuple[ScanRound, frozenset[DeviceClass], str]]] = defaultdict(list)
    round_index = 0
    for (base, tile_start), slots in sorted(grouped.items()):
        if set(slots) != {0, 1, 2, 3}:
            continue
        if any(bool(row.get("has_ignore", False)) for row, _ in slots.values()):
            continue
        end_time_us = (round_index + 1) * ROUND_DURATION_US
        truth_devices: set[DeviceClass] = set()
        hard_negative = False
        tiles: list[TileObservation] = []
        for slot in range(4):
            row, row_scores = slots[slot]
            hard_negative = hard_negative or bool(row.get("hard_negative", False))
            positives = {DetectionClass(int(value)) for value in row.get("class_indices", [])}
            truth_devices.update(DETECTION_TO_DEVICE[value] for value in positives)
            events = []
            for class_id in DetectionClass:
                if class_id.value >= 2 and slot >= 2:
                    continue
                score = float(row_scores[class_id.value])
                if score >= _lowest_threshold(config, class_id):
                    events.append(
                        DetectionEvidence(
                            class_id=class_id,
                            confidence=score,
                            roi_decision=RoiDecision.PASS,
                        )
                    )
            tiles.append(
                TileObservation(
                    center_frequency_hz=CENTER_FREQUENCIES_HZ[slot],
                    capture_end_time_us=end_time_us - (3 - slot) * 100_000,
                    events=tuple(events),
                )
            )
        kind = "positive" if truth_devices else ("hard_negative" if hard_negative else "true_empty")
        sequences[base].append(
            (
                ScanRound(round_index=round_index, end_time_us=end_time_us, tiles=tuple(tiles)),
                frozenset(truth_devices),
                kind,
            )
        )
        round_index += 1
    return dict(sequences)


def _synthetic_round(
    index: int,
    events: Mapping[int, Sequence[DetectionEvidence]] | None = None,
    *,
    invalid_slot: int | None = None,
) -> ScanRound:
    events = events or {}
    end_time_us = (index + 1) * ROUND_DURATION_US
    tiles = []
    for slot, center in enumerate(CENTER_FREQUENCIES_HZ):
        tiles.append(
            TileObservation(
                center_frequency_hz=center,
                capture_end_time_us=end_time_us - (3 - slot) * 100_000,
                events=tuple(events.get(slot, ())),
                validity=(
                    TileValidity.INVALID if slot == invalid_slot else TileValidity.VALID
                ),
                quality_flags=(
                    TileQualityFlag.CRC_ERROR | TileQualityFlag.PACKET_GAP
                    if slot == invalid_slot
                    else TileQualityFlag.NONE
                ),
            )
        )
    return ScanRound(index, end_time_us, tuple(tiles))


def _strong_event(class_id: DetectionClass) -> DetectionEvidence:
    return DetectionEvidence(class_id, 0.99, RoiDecision.PASS)


def synthetic_acceptance(config: FusionConfig) -> dict[str, object]:
    isolated = ActivityFusion(config).update(
        _synthetic_round(0, {0: (_strong_event(DetectionClass.DJI_VIDEO),)})
    )
    isolated_ok = all(
        item.state is not ActivityState.WORKING for item in isolated.devices.values()
    )

    dji_source_results: dict[str, bool] = {}
    for source in (DetectionClass.DJI_CONTROL, DetectionClass.DJI_VIDEO):
        fusion = ActivityFusion(config)
        fusion.update(_synthetic_round(0, {0: (_strong_event(source),)}))
        result = fusion.update(_synthetic_round(1, {3: (_strong_event(source),)}))
        dji_source_results[source.name] = (
            result.devices[DeviceClass.DJI].state is ActivityState.WORKING
        )

    hold_counts: dict[str, int] = {}
    confirmation_rounds: dict[str, int | None] = {}
    for class_id, device in DETECTION_TO_DEVICE.items():
        if class_id is DetectionClass.DJI_VIDEO:
            continue
        fusion = ActivityFusion(config)
        confirmed = None
        for index in range(4):
            snapshot = fusion.update(
                _synthetic_round(index, {0: (_strong_event(class_id),)})
            )
            if snapshot.devices[device].state is ActivityState.WORKING:
                confirmed = index + 1
                break
        confirmation_rounds[class_id.name] = confirmed
        start = confirmed or 4
        empty_count = 0
        for index in range(start, start + 20):
            snapshot = fusion.update(_synthetic_round(index))
            if snapshot.devices[device].state is not ActivityState.WORKING:
                break
            empty_count += 1
        hold_counts[class_id.name] = empty_count

    hold_fusion = ActivityFusion(config)
    before = hold_fusion.update(
        _synthetic_round(0, {0: (_strong_event(DetectionClass.AT9S),)})
    ).devices[DeviceClass.AT9S].evidence
    invalid = hold_fusion.update(_synthetic_round(1, invalid_slot=2))
    invalid_hold_ok = (
        invalid.devices[DeviceClass.AT9S].evidence == before
        and not invalid.round_complete
    )
    return {
        "single_isolated_detection_does_not_work": isolated_ok,
        "dji_single_source_can_work": dji_source_results,
        "confirmation_rounds": confirmation_rounds,
        "empty_rounds_held_after_working": hold_counts,
        "invalid_round_holds_without_leak": invalid_hold_ok,
        "passed": isolated_ok and invalid_hold_ok and all(dji_source_results.values())
        and all(value is not None and value <= 3 for value in confirmation_rounds.values()),
    }


def _false_working_metrics(
    sequences: Mapping[str, Sequence[tuple[ScanRound, frozenset[DeviceClass], str]]],
    config: FusionConfig,
    kind: str,
) -> dict[str, object]:
    entries: list[list[tuple[ScanRound, frozenset[DeviceClass], str]]] = []
    for rounds in sequences.values():
        current: list[tuple[ScanRound, frozenset[DeviceClass], str]] = []
        for item in rounds:
            _, truth, row_kind = item
            if not truth and row_kind == kind:
                current.append(item)
            elif current:
                entries.append(current)
                current = []
        if current:
            entries.append(current)
    transition_counts = {device.name: 0 for device in DeviceClass}
    round_count = 0
    for rounds in entries:
        fusion = ActivityFusion(config)
        previous = {device: ActivityState.NO_RF_OBSERVED for device in DeviceClass}
        for scan_round, _, _ in rounds:
            snapshot = fusion.update(scan_round)
            round_count += 1
            for device in DeviceClass:
                current = snapshot.devices[device].state
                if current is ActivityState.WORKING and previous[device] is not current:
                    transition_counts[device.name] += 1
                previous[device] = current
    hours = round_count * ROUND_DURATION_US / 1_000_000.0 / 3600.0
    total = sum(transition_counts.values())
    return {
        "sequence_count": len(entries),
        "round_count": round_count,
        "replay_hours": hours,
        "working_entry_count": total,
        "working_entries_per_hour": None if hours == 0.0 else total / hours,
        "per_device_working_entry_count": transition_counts,
    }


def _positive_delay_metrics(
    sequences: Mapping[str, Sequence[tuple[ScanRound, frozenset[DeviceClass], str]]],
    config: FusionConfig,
) -> dict[str, object]:
    delays: dict[DeviceClass, list[float]] = defaultdict(list)
    totals = {device: 0 for device in DeviceClass}
    for rounds in sequences.values():
        present = set().union(*(truth for _, truth, _ in rounds)) if rounds else set()
        if not present:
            continue
        fusion = ActivityFusion(config)
        first_truth: dict[DeviceClass, int] = {}
        confirmed: set[DeviceClass] = set()
        for scan_round, truth, _ in rounds:
            for device in truth:
                first_truth.setdefault(device, scan_round.end_time_us)
            snapshot = fusion.update(scan_round)
            for device in present - confirmed:
                if (
                    device in first_truth
                    and snapshot.devices[device].state is ActivityState.WORKING
                ):
                    delays[device].append(
                        (scan_round.end_time_us - first_truth[device]) / 1_000_000.0
                    )
                    confirmed.add(device)
        for device in present:
            totals[device] += 1
    result: dict[str, object] = {}
    for device in DeviceClass:
        values = delays[device]
        result[device.name] = {
            "positive_sequence_count": totals[device],
            "confirmed_sequence_count": len(values),
            "confirmation_rate": None if totals[device] == 0 else len(values) / totals[device],
            "median_delay_seconds": None if not values else statistics.median(values),
            "p95_delay_seconds": None if not values else float(np.quantile(values, 0.95)),
        }
    return result


def ablation(
    sequences: Mapping[str, Sequence[tuple[ScanRound, frozenset[DeviceClass], str]]],
    base: FusionConfig,
) -> list[dict[str, object]]:
    rows = []
    for leak in (0.75, 0.85, 0.92):
        for enter in (3.0, 4.0, 4.5, 5.0):
            for exit_threshold in (0.5, 1.0, 1.5):
                if exit_threshold >= enter:
                    continue
                config = replace(
                    base,
                    leak=leak,
                    working_enter_threshold=enter,
                    working_exit_threshold=exit_threshold,
                    no_rf_threshold=exit_threshold,
                )
                synthetic = synthetic_acceptance(config)
                empty = _false_working_metrics(sequences, config, "true_empty")
                hard = _false_working_metrics(sequences, config, "hard_negative")
                rows.append(
                    {
                        "leak": leak,
                        "working_enter": enter,
                        "working_exit": exit_threshold,
                        "synthetic_passed": synthetic["passed"],
                        "true_empty_working_entries_per_hour": empty["working_entries_per_hour"],
                        "hard_negative_working_entries_per_hour": hard["working_entries_per_hour"],
                        "empty_rounds_held_after_working": synthetic["empty_rounds_held_after_working"],
                    }
                )
    return rows


def run(args: argparse.Namespace) -> dict[str, object]:
    activity_dir = args.activity_dir.resolve()
    calibration_path = activity_dir / "activity_calibration.json"
    calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
    config = config_from_report(calibration)
    sequences = build_validation_proxy_sequences(
        args.cache.resolve(),
        activity_dir / "validation_peak_scores.f32.npy",
        config,
    )
    synthetic = synthetic_acceptance(config)
    true_empty = _false_working_metrics(sequences, config, "true_empty")
    hard_negative = _false_working_metrics(sequences, config, "hard_negative")
    positive_delay = _positive_delay_metrics(sequences, config)
    report: dict[str, object] = {
        "schema_version": "13.0.0",
        "pipeline": "ra8p1_v13_activity_state_replay",
        "status": "software_replay_passed_real_continuous_iq_pending",
        "calibration_sha256": _sha256(calibration_path),
        "round_duration_us": ROUND_DURATION_US,
        "validation_proxy_sequence_count": len(sequences),
        "validation_proxy_round_count": sum(len(value) for value in sequences.values()),
        "synthetic_acceptance": synthetic,
        "validation_derived_replay": {
            "true_empty": true_empty,
            "hard_negative_interference_proxy": hard_negative,
            "positive_confirmation_delay": positive_delay,
        },
        "ablation": ablation(sequences, config),
        "acceptance": {
            "single_isolated_false_does_not_work": synthetic["single_isolated_detection_does_not_work"],
            "invalid_round_does_not_reduce_evidence": synthetic["invalid_round_holds_without_leak"],
            "dji_control_only_and_video_only_can_work": all(synthetic["dji_single_source_can_work"].values()),
            "frequency_hop_does_not_drop_dji": synthetic["dji_single_source_can_work"]["DJI_CONTROL"],
            "software_gate_passed": synthetic["passed"],
            "real_continuous_four_frequency_iq_gate_passed": False,
        },
        "limitations": [
            "The validation-derived replay groups four center-slot tiles by recording stem and tile start; the source captures are sequential files, not a timestamped continuous four-frequency board stream.",
            "Every decoded validation peak is treated as ROI PASS for a conservative false-state stress test because historical cache rows do not contain CPU0 ROI verdict logs.",
            "Hard-negative rows are an interference proxy; Wi-Fi and Bluetooth subtypes are not separately tagged in the frozen cache.",
            "A real SDR gain-matched continuous IQ replay remains a deployment acceptance gate and must not be claimed from this software proxy.",
        ],
    }
    report["report_sha256"] = _canonical_hash(report, "report_sha256")
    _write_json(activity_dir / "activity_replay_report.json", report)
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Replay and ablate V13 activity fusion.")
    parser.add_argument("--activity-dir", type=Path, default=DEFAULT_ACTIVITY_DIR)
    parser.add_argument("--cache", type=Path, default=DEFAULT_CACHE)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    report = run(args)
    print(
        json.dumps(
            {
                "status": report["status"],
                "software_gate_passed": report["acceptance"]["software_gate_passed"],
                "validation_proxy_round_count": report["validation_proxy_round_count"],
                "report_sha256": report["report_sha256"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if report["acceptance"]["software_gate_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
