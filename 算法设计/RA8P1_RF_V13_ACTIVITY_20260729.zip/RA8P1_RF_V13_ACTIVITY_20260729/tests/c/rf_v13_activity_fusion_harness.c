#include "rf_v13_activity_fusion.h"

#include <stdio.h>

static void close_valid_round(rf_v13_cpu0_round_message_t *message)
{
    message->observed_slot_mask = RF_V13_CENTER_SLOT_MASK;
    message->valid_slot_mask = RF_V13_CENTER_SLOT_MASK;
    message->round_flags =
        RF_V13_ROUND_COMPLETE | RF_V13_ROUND_V12_TILES_VALIDATED;
}

static void print_state(
    uint32_t round_index,
    rf_v13_apply_result_t result,
    const rf_v13_activity_fusion_t *fusion)
{
    unsigned int object_id;
    printf("%u,%d", (unsigned int)round_index, (int)result);
    for (object_id = 0u; object_id < RF_V13_OBJECT_COUNT; ++object_id) {
        const rf_v13_object_state_t *state = &fusion->objects[object_id];
        printf(",%ld,%u", (long)state->energy_q12,
               (unsigned int)state->activity_state);
    }
    printf("\n");
}

int main(void)
{
    rf_v13_activity_fusion_t fusion;
    rf_v13_cpu0_round_message_t message;
    rf_v13_apply_result_t result;
    uint32_t round_index;

    rf_v13_activity_fusion_init(&fusion);
    for (round_index = 0u; round_index < 12u; ++round_index) {
        uint64_t start_us = (uint64_t)round_index * UINT64_C(586000);
        uint64_t end_us = start_us + UINT64_C(586000);
        rf_v13_cpu0_round_message_init(
            &message, round_index + 1u, round_index, start_us, end_us);
        close_valid_round(&message);
        if (round_index < 2u) {
            if (rf_v13_cpu0_add_v12_detection(
                    &message, RF_V13_CLASS_AT9S, (uint8_t)round_index,
                    UINT16_C(32767), RF_V13_ROI_PASS, INT16_C(0), UINT8_C(0),
                    end_us - UINT64_C(100000)) != 1) {
                return 10;
            }
            if (rf_v13_cpu0_add_v12_detection(
                    &message, RF_V13_CLASS_DJI_CONTROL,
                    round_index == 0u ? UINT8_C(0) : UINT8_C(3),
                    UINT16_C(32767), RF_V13_ROI_PASS, INT16_C(0), UINT8_C(0),
                    end_us - UINT64_C(50000)) != 1) {
                return 11;
            }
            /* Duplicate same-class evidence must not add another LLR. */
            if (rf_v13_cpu0_add_v12_detection(
                    &message, RF_V13_CLASS_DJI_CONTROL, UINT8_C(1),
                    UINT16_C(30000), RF_V13_ROI_PASS,
                    RF_V13_MAX_PERIOD_BONUS_Q12, UINT8_C(0),
                    end_us - UINT64_C(150000)) != 1) {
                return 12;
            }
        }
        if (round_index == 2u) {
            message.valid_slot_mask = UINT8_C(0x0b);
            message.invalid_reason_flags = RF_V13_INVALID_CRC;
        }
        result = rf_v13_activity_fusion_apply_smoke(&fusion, &message);
        print_state(round_index, result, &fusion);
    }

    rf_v13_cpu0_round_message_init(
        &message, UINT32_C(99), UINT32_C(99), UINT64_C(0), UINT64_C(586000));
    if (rf_v13_cpu0_add_v12_detection(
            &message, RF_V13_CLASS_T12, UINT8_C(2), UINT16_C(32767),
            RF_V13_ROI_PASS, INT16_C(0), UINT8_C(0), UINT64_C(1)) != 0) {
        return 20;
    }
    return 0;
}
