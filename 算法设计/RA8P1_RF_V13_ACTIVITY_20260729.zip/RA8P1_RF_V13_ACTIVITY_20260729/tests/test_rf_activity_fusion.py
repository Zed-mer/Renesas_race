from __future__ import annotations

import json

import pytest

from training.rf_activity_fusion import (
    ActivityFusion,
    ActivityState,
    CENTER_FREQUENCIES_HZ,
    DetectionClass,
    DetectionEvidence,
    DeviceClass,
    FrequencyBand,
    FusionConfig,
    RoiDecision,
    ScanRound,
    TileObservation,
    TileQualityFlag,
    TileValidity,
    TransitionReason,
    UpdateReason,
    aggregate_round,
)


def _event(
    class_id: DetectionClass,
    confidence: float = 0.95,
    *,
    roi: RoiDecision = RoiDecision.PASS,
    period_bonus: float = 0.0,
    event_id: int | None = None,
) -> DetectionEvidence:
    return DetectionEvidence(
        class_id=class_id,
        confidence=confidence,
        roi_decision=roi,
        period_bonus=period_bonus,
        event_id=event_id,
    )


def _round(
    round_index: int,
    events_by_center: dict[int, tuple[DetectionEvidence, ...]] | None = None,
    *,
    missing_centers: frozenset[int] = frozenset(),
    invalid_center: int | None = None,
    flags: TileQualityFlag = TileQualityFlag.NONE,
) -> ScanRound:
    events_by_center = events_by_center or {}
    end_time_us = (round_index + 1) * 600_000
    tiles = tuple(
        TileObservation(
            center_frequency_hz=center,
            capture_end_time_us=end_time_us - (3 - center_index) * 100_000,
            events=events_by_center.get(center, ()),
            validity=(
                TileValidity.BACKGROUND_NOT_READY
                if center == invalid_center
                else TileValidity.VALID
            ),
            quality_flags=flags if center == invalid_center else TileQualityFlag.NONE,
        )
        for center_index, center in enumerate(CENTER_FREQUENCIES_HZ)
        if center not in missing_centers
    )
    return ScanRound(round_index=round_index, end_time_us=end_time_us, tiles=tiles)


def test_single_isolated_strong_detection_does_not_enter_working() -> None:
    fusion = ActivityFusion()

    snapshot = fusion.update(
        _round(
            0,
            {CENTER_FREQUENCIES_HZ[0]: (_event(DetectionClass.AT9S),)},
        )
    )

    state = snapshot.devices[DeviceClass.AT9S]
    assert state.evidence == pytest.approx(3.0)
    assert state.state is ActivityState.UNCERTAIN
    assert state.last_transition_reason is TransitionReason.ENTERED_UNCERTAIN


def test_two_strong_rounds_enter_working_and_preserve_source_fields() -> None:
    fusion = ActivityFusion()
    for round_index in range(2):
        snapshot = fusion.update(
            _round(
                round_index,
                {CENTER_FREQUENCIES_HZ[1]: (_event(DetectionClass.T12),)},
            )
        )

    state = snapshot.devices[DeviceClass.T12]
    assert state.evidence == pytest.approx(5.55)
    assert state.state is ActivityState.WORKING
    assert state.evidence_source_class is DetectionClass.T12
    assert state.last_center_frequency_hz == CENTER_FREQUENCIES_HZ[1]
    assert state.last_band is FrequencyBand.BAND_2_4_GHZ
    assert state.last_trusted_detection_time_us == snapshot.end_time_us - 200_000
    assert state.last_transition_reason is TransitionReason.ENTERED_WORKING


def test_working_state_survives_six_empty_rounds_then_exits_on_seventh() -> None:
    fusion = ActivityFusion()
    fusion.update(
        _round(0, {CENTER_FREQUENCIES_HZ[0]: (_event(DetectionClass.XIAOBAWANG),)})
    )
    fusion.update(
        _round(1, {CENTER_FREQUENCIES_HZ[0]: (_event(DetectionClass.XIAOBAWANG),)})
    )

    for round_index in range(2, 8):
        snapshot = fusion.update(_round(round_index))
        assert snapshot.devices[DeviceClass.XIAOBAWANG].state is ActivityState.WORKING

    snapshot = fusion.update(_round(8))
    state = snapshot.devices[DeviceClass.XIAOBAWANG]
    assert state.evidence <= 1.0
    assert state.state is ActivityState.NO_RF_OBSERVED
    assert (
        state.last_transition_reason
        is TransitionReason.EXITED_WORKING_AFTER_EVIDENCE_DECAY
    )


@pytest.mark.parametrize(
    "invalid_round",
    [
        _round(1, missing_centers=frozenset({CENTER_FREQUENCIES_HZ[3]})),
        _round(
            1,
            invalid_center=CENTER_FREQUENCIES_HZ[2],
            flags=TileQualityFlag.CRC_ERROR | TileQualityFlag.PACKET_GAP,
        ),
    ],
)
def test_incomplete_or_invalid_round_holds_evidence_without_leak(
    invalid_round: ScanRound,
) -> None:
    fusion = ActivityFusion()
    first = fusion.update(
        _round(0, {CENTER_FREQUENCIES_HZ[0]: (_event(DetectionClass.AT9S),)})
    )
    before = first.devices[DeviceClass.AT9S]

    snapshot = fusion.update(invalid_round)
    after = snapshot.devices[DeviceClass.AT9S]

    assert snapshot.round_complete is False
    assert after.evidence == before.evidence
    assert after.state is before.state
    assert after.last_trusted_detection_time_us == before.last_trusted_detection_time_us
    assert after.current_round_complete is False
    assert after.last_update_reason is UpdateReason.INCOMPLETE_OR_INVALID_ROUND_HELD


def test_dji_control_hopping_between_bands_keeps_one_device_state() -> None:
    fusion = ActivityFusion()
    fusion.update(
        _round(0, {CENTER_FREQUENCIES_HZ[0]: (_event(DetectionClass.DJI_CONTROL),)})
    )
    snapshot = fusion.update(
        _round(1, {CENTER_FREQUENCIES_HZ[3]: (_event(DetectionClass.DJI_CONTROL),)})
    )

    state = snapshot.devices[DeviceClass.DJI]
    assert state.state is ActivityState.WORKING
    assert state.evidence_source_class is DetectionClass.DJI_CONTROL
    assert state.last_band is FrequencyBand.BAND_5_8_GHZ


@pytest.mark.parametrize(
    "source_class",
    [DetectionClass.DJI_CONTROL, DetectionClass.DJI_VIDEO],
)
def test_either_dji_source_alone_can_establish_working(
    source_class: DetectionClass,
) -> None:
    fusion = ActivityFusion()
    for round_index in range(2):
        snapshot = fusion.update(
            _round(
                round_index,
                {CENTER_FREQUENCIES_HZ[2]: (_event(source_class),)},
            )
        )

    state = snapshot.devices[DeviceClass.DJI]
    assert state.state is ActivityState.WORKING
    assert state.evidence_source_class is source_class


@pytest.mark.parametrize(
    "class_id,device",
    [
        (DetectionClass.AT9S, DeviceClass.AT9S),
        (DetectionClass.T12, DeviceClass.T12),
        (DetectionClass.XIAOBAWANG, DeviceClass.XIAOBAWANG),
    ],
)
def test_non_dji_evidence_is_rejected_outside_2_4_ghz(
    class_id: DetectionClass,
    device: DeviceClass,
) -> None:
    fusion = ActivityFusion()

    snapshot = fusion.update(
        _round(0, {CENTER_FREQUENCIES_HZ[2]: (_event(class_id),)})
    )

    state = snapshot.devices[device]
    assert state.evidence == pytest.approx(-0.25)
    assert state.state is ActivityState.NO_RF_OBSERVED
    assert state.evidence_source_class is None


def test_same_class_duplicates_take_max_once_instead_of_summing() -> None:
    duplicates = tuple(
        _event(DetectionClass.DJI_VIDEO, confidence=score, event_id=index)
        for index, score in enumerate((0.91, 0.99, 0.95, 0.80))
    )
    scan_round = _round(
        0,
        {
            CENTER_FREQUENCIES_HZ[0]: duplicates[:2],
            CENTER_FREQUENCIES_HZ[2]: duplicates[2:],
        },
    )

    aggregated = aggregate_round(scan_round)
    dji = aggregated.evidence[DeviceClass.DJI]
    assert dji.accepted_before_dedup == 4
    assert dji.llr == pytest.approx(3.0)
    assert dji.confidence == pytest.approx(0.99)

    state = ActivityFusion().update(scan_round).devices[DeviceClass.DJI]
    assert state.evidence == pytest.approx(3.0)


def test_dji_control_and_video_are_fused_with_max_not_sum() -> None:
    aggregated = aggregate_round(
        _round(
            0,
            {
                CENTER_FREQUENCIES_HZ[0]: (_event(DetectionClass.DJI_CONTROL),),
                CENTER_FREQUENCIES_HZ[2]: (_event(DetectionClass.DJI_VIDEO),),
            },
        )
    )
    dji = aggregated.evidence[DeviceClass.DJI]
    assert dji.accepted_before_dedup == 2
    assert dji.llr == pytest.approx(3.0)


def test_roi_fail_is_not_positive_and_unknown_is_configurably_downweighted() -> None:
    scan_round = _round(
        0,
        {
            CENTER_FREQUENCIES_HZ[0]: (
                _event(DetectionClass.AT9S, roi=RoiDecision.FAIL),
                _event(
                    DetectionClass.T12,
                    roi=RoiDecision.UNKNOWN,
                    period_bonus=0.9,
                ),
            )
        },
    )

    aggregated = aggregate_round(scan_round)
    assert aggregated.evidence[DeviceClass.AT9S].llr == pytest.approx(-0.25)
    assert aggregated.evidence[DeviceClass.T12].llr == pytest.approx(1.65)

    disabled = aggregate_round(scan_round, FusionConfig(unknown_roi_scale=0.0))
    assert disabled.evidence[DeviceClass.T12].llr == pytest.approx(-0.25)


def test_snapshot_is_json_serializable_and_never_reports_off() -> None:
    snapshot = ActivityFusion().update(_round(0))

    encoded = json.dumps(snapshot.to_dict(), sort_keys=True)

    assert "NO_RF_OBSERVED" in encoded
    assert '"OFF"' not in encoded


def test_round_indices_cannot_be_replayed_to_inflate_evidence() -> None:
    fusion = ActivityFusion()
    scan_round = _round(
        0,
        {CENTER_FREQUENCIES_HZ[0]: (_event(DetectionClass.AT9S),)},
    )
    fusion.update(scan_round)

    with pytest.raises(ValueError, match="strictly increasing"):
        fusion.update(scan_round)
