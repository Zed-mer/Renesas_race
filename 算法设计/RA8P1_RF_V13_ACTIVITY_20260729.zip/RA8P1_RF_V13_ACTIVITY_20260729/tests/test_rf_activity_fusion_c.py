from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT_ROOT / "deploy" / "ra8p1_v13" / "rf_v13_activity_fusion.c"
INCLUDE = SOURCE.parent
HARNESS = PROJECT_ROOT / "tests" / "c" / "rf_v13_activity_fusion_harness.c"
CALIBRATION = (
    PROJECT_ROOT / "output" / "ra8p1_v13_activity" / "rf_v13_activity_calibration.c"
)
CALIBRATION_INCLUDE = CALIBRATION.parent


def _vcvars() -> Path | None:
    vswhere = Path(
        r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    )
    if not vswhere.is_file():
        return None
    result = subprocess.run(
        [
            str(vswhere),
            "-latest",
            "-products",
            "*",
            "-requires",
            "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
            "-property",
            "installationPath",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    if not result.stdout.strip():
        return None
    path = Path(result.stdout.strip()) / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"
    return path if path.is_file() else None


def _compile(command: str) -> None:
    vcvars = _vcvars()
    if vcvars is None:
        pytest.skip("MSVC C toolchain is unavailable")
    completed = subprocess.run(
        f'call "{vcvars}" >nul && {command}',
        cwd=PROJECT_ROOT,
        check=False,
        capture_output=True,
        text=True,
        shell=True,
        executable=os.environ.get("COMSPEC", "cmd.exe"),
    )
    assert completed.returncode == 0, completed.stdout + completed.stderr


def _q12_multiply(left: int, right: int) -> int:
    product = left * right
    if product >= 0:
        return (product + 2048) >> 12
    return -(((-product) + 2048) >> 12)


def _next_state(previous: int, energy: int) -> int:
    if previous == 2:
        return 0 if energy < 4096 else 2
    if energy >= 16384:
        return 2
    if energy > 4096:
        return 1
    return 0


def test_c_q20_12_matches_python_round_by_round(tmp_path: Path) -> None:
    executable = tmp_path / "rf_v13_golden.exe"
    _compile(
        "cl.exe /nologo /std:c11 /W4 /WX "
        f'"{HARNESS.relative_to(PROJECT_ROOT)}" '
        f'"{SOURCE.relative_to(PROJECT_ROOT)}" '
        f'/I "{INCLUDE.relative_to(PROJECT_ROOT)}" /Fe:"{executable}"'
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    observed = [tuple(int(value) for value in line.split(",")) for line in completed.stdout.splitlines()]

    energy = [0, 0, 0, 0]
    state = [0, 0, 0, 0]
    expected = []
    for round_index in range(12):
        if round_index == 2:
            result = 1
        else:
            result = 0
            observations = [13517, 12288, -1024, -1024] if round_index < 2 else [-1024] * 4
            for object_id in range(4):
                energy[object_id] = max(
                    -32768,
                    min(32768, _q12_multiply(energy[object_id], 3482) + observations[object_id]),
                )
                state[object_id] = _next_state(state[object_id], energy[object_id])
        row = [round_index, result]
        for object_id in range(4):
            row.extend((energy[object_id], state[object_id]))
        expected.append(tuple(row))

    assert observed == expected


def test_generated_deployment_calibration_compiles(tmp_path: Path) -> None:
    if not CALIBRATION.is_file():
        pytest.skip("run calibrate_ra8p1_v13_activity.py first")
    object_path = tmp_path / "rf_v13_calibration.obj"
    _compile(
        "cl.exe /nologo /std:c11 /W4 /WX /c "
        f'"{CALIBRATION.relative_to(PROJECT_ROOT)}" '
        f'/I "{INCLUDE.relative_to(PROJECT_ROOT)}" '
        f'/I "{CALIBRATION_INCLUDE.relative_to(PROJECT_ROOT)}" '
        f'/Fo:"{object_path}"'
    )
    assert object_path.is_file()
