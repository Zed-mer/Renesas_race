from __future__ import annotations

import numpy as np

from scripts.calibrate_ra8p1_v13_activity import (
    CalibrationSample,
    build_samples,
    fit_llr_table,
)


def test_tail_llr_is_monotonic_and_strong_scores_are_more_informative() -> None:
    samples = [
        *(CalibrationSample(0, score, True, "positive") for score in (0.6, 0.8, 0.92, 0.98)),
        *(CalibrationSample(0, score, False, "true_empty") for score in (0.1, 0.2, 0.4, 0.58)),
        CalibrationSample(0, 0.78, False, "hard_negative", weight=2.0),
    ]

    report = fit_llr_table(samples)
    llrs = [float(item["llr"]) for item in report["bins"]]

    assert llrs == sorted(llrs)
    assert llrs[-1] > llrs[0]
    assert all(value <= 3.0 for value in llrs)


def test_sample_builder_excludes_ignore_and_gates_non_dji_at_5p8() -> None:
    rows = [
        {
            "recording_id": "recording_f2",
            "class_indices": [0],
            "hard_negative": False,
            "has_ignore": False,
        },
        {
            "recording_id": "ignored_f0",
            "class_indices": [],
            "hard_negative": False,
            "has_ignore": True,
        },
    ]
    scores = np.full((2, 5), 0.9, dtype=np.float32)

    samples = build_samples(rows, scores, hard_negative_weight=2.0)

    assert {sample.class_id for sample in samples} == {0, 1}
    assert sum(sample.positive for sample in samples) == 1


def test_hard_negative_weight_is_preserved() -> None:
    rows = [
        {
            "recording_id": "hard_f0",
            "class_indices": [],
            "hard_negative": True,
            "has_ignore": False,
        }
    ]
    samples = build_samples(rows, np.full((1, 5), 0.7, dtype=np.float32), 3.0)

    assert all(sample.negative_kind == "hard_negative" for sample in samples)
    assert all(sample.weight == 3.0 for sample in samples)
