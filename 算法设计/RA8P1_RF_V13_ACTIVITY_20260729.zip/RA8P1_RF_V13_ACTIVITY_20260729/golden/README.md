# V12 model tensor golden

Only V2/V3 quantized tensor inputs and outputs are included. The V2 physical video output remains present only to verify its unchanged ABI and must not be copied into the production heatmap set. No raw IQ, STFT, or IQ-to-feature byte golden is claimed.
